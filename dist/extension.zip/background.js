/**
 * Chromebook 児童端末管理クライアント - Background Service Worker (Manifest V3)
 * ・児童Googleアカウントの自動検出 & 自動同期
 * ・管理コンソール (Managed Storage) ポリシー対応
 * ・Google検索画面 & 特殊タブの確実なロック
 * ・ロック解除の全タブ高速反映
 */

// 【ブートストラップ用】親GASの Web アプリ URL（/exec）。
//   Managed Storage ポリシー（gas_url / gas_url_map）が未配布の端末でも、
//   ここに親の /exec を入れておけば初回同期が成立し、親が assigned_gas_url を
//   返して以降は子GASへ直接つながる（1校240台を子GASへ分散する R41 構成の入口）。
//   ※ 空のままなら端末は通信できない。その事実は sync_diag とコンソールへ
//     必ず出す（無言で停止させない）。
const DEFAULT_GAS_URL = '';

// デフォルト設定
const DEFAULT_CONFIG = {
  student_id: '',
  gas_url: '', // 管理コンソールまたはpopupまたは教員画面で指定
  // 学校名 → GAS WebアプリURL のマッピング。
  // 13校それぞれのGAS（スプレッドシート）に、1つの拡張機能から振り分けるためのルーティング表。
  // 管理コンソールの Managed Storage ポリシー（gas_url_map）で配布する。
  gas_url_map: {},
  screen_lock: false,
  filter_mode: 'OFF', // 'OFF' | 'WHITELIST' | 'BLACKLIST'
  whitelist_urls: ['nhk.or.jp', 'scratch.mit.edu', 'google.com'],
  blacklist_urls: ['youtube.com', 'twitter.com', 'tiktok.com', 'instagram.com'],
  last_broadcast_id: '',
  last_screen_request: '', // 画面一覧: 最後に処理した画面情報要求ID（押下時のみ撮影するための二重実行防止）
  last_sync_time: null
};

// 拡張機能インストール時の初期化 & 即時同期
chrome.runtime.onInstalled.addListener(async (details) => {
  console.log('[EduAgent] 拡張機能がインストール/更新されました:', details.reason);
  await initializeClient();
});

// ブラウザ起動時の初期化 & 即時同期
chrome.runtime.onStartup.addListener(async () => {
  console.log('[EduAgent] ブラウザが起動しました');
  await initializeClient();
});

// 定期アラームの受信
//  ・syncAlarm      … 稼働中のバックストップ（30 秒）。教員コンソール稼働中のみ登録する。
//  ・keepAliveAlarm … 旧名（後方互換）。
//  ・idleDriftAlarm … 稼働→非稼働へ切り替わった直後の猶予期間だけ、再開を確認するための低頻度起床。
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'syncAlarm' || alarm.name === 'keepAliveAlarm') {
    maybeSync();
  } else if (alarm.name === 'idleDriftAlarm') {
    maybeSync();
  } else if (alarm.name === 'wakeAlarm') {
    // 非稼働中でも「先生が復帰したか」だけを軽く確認する（シート非接触の短い応答）。
    probeWake();
  } else if (alarm.name === 'schedulePoll') {
    // 【低速ポーリング】教員コンソールが閉じられたままでも、予約を保持している端末は
    //   5 分ごとに起床して親／子GASへハートビートを送り、新規予約を取りこぼさない。
    //   （時間制限タイマーが実機で発動しない問題の対策。未割り当て・予約ゼロの端末は
    //      maybeSync 側が同期せずアラームも解除するため、通信負荷は増えない）
    maybeSync();
  } else if (alarm.name === 'scheduleEdge' || alarm.name === 'scheduleTick') {
    // 【フェーズ3】スケジュール（タイマー）の境界発動。
    //   scheduleEdge … 開始/終了時刻ちょうどに1回だけ起こす（本命）
    //   scheduleTick … 1分ごとの見張り（Edge を取りこぼした場合の保険）
    //   どちらも通信せず、storage にキャッシュした予約だけで判定する（オフライン保護）。
    reevaluateSchedules().catch(e => {
      console.warn('[EduAgent] スケジュール再評価エラー:', e && e.message ? e.message : e);
    });
  }
});

// ==================== 教員コンソールの稼働に連動する同期周期 ====================
// 課題: 児童端末が常時 1.5 秒間隔でハートビート（doPost）し、管理アプリを開いていなくても
//       GAS 実行が数秒おきに走り続ける（通信負荷）。
// v1.6.0: 「管理アプリを誰も起動していないときは通信しない」を徹底する。
//   ・稼働中（ka_active=true）: 1.5 秒間隔で速く反映（＋30 秒アラームのバックストップ）。
//   ・非稼働（ka_active=false）: **定期ポーリングを行わない（doPost = 0）**。
//       ただし「稼働→非稼働」に切り替わった直後の猶予期間（GAS の idle_drift_until）だけ、
//       管理アプリがすぐ再度開かれるケースに備えて低頻度（1 秒上限）で再確認する。
//       猶予が尽きたらアラームを止め、完全に通信を停止する（＝無駄な通信ゼロ）。
//   ・停止後に管理アプリが再度開かれた場合は、新しいタブの作成/更新（＝コンソールURL）を
//     検知して即座に通常同期へ復帰する（resumeFromConsoleTab）。
//   ※ 児童端末は GAS としか通信できないため、稼働判定は GAS（ka_active）を介する。
let keepaliveActive = false; // GAS のハートビート応答 ka_active を反映
let activeIntervalMs = 1500; // 稼働中の同期周期（GAS の sync_interval_sec で上書きされる）
let idleDriftUntil = 0;      // 非稼働時、この時刻までは低頻度で再確認する（0=猶予なし）
// 【v1.6.6】稼働中（ka_active=true）の高精度ポーリング用の状態。
//   chrome.alarms は最短 30 秒でしか鳴らず、Chrome のスロットリングで更に遅れる。
//   そこで Service Worker 内の setTimeout チェーンを主軸にし、alarms はフェイルセーフとして併存させる。
let fastChainTimer = null;      // 稼働中の setTimeout チェーン（1本だけ保持）
const FAST_MIN_GAP_RATIO = 0.8; // 重複抑止しきい値（sync_interval_sec × 0.8 秒未満は再送しない）
let lastHeartbeatStartMs = 0;   // 直近ハートビートの「送信開始」時刻（重複排除用）

// 【v1.6.7】スリープ復帰（蓋を開けた／画面ロック解除／ウィンドウ復帰）の即時ハートビート。
//   課題: 蓋を閉じてスリープ → 開けて Wi-Fi が繋がっても、次の setTimeout／chrome.alarms まで
//         待たされるため、管理画面の「オンライン状態」へ戻るのに時間がかかっていた。
//   方針: 復帰イベントの瞬間に 1 回だけ即時送信する。ただし通常のウィンドウ切替で毎回
//         通信しないよう「前回の【成功】から 5 秒」のクールダウンと syncInFlight を併用する。
const WAKE_RESUME_COOLDOWN_MS = 5000; // 前回の成功送信からこの時間未満の復帰通知は捨てる
const WAKE_RETRY_DELAY_MS = 2000;     // 復帰直後の通信失敗は短い間隔（2 秒）で再試行する
const WAKE_RETRY_MAX = 2;             // 短い再試行の上限（長いエラーバックオフへは入らない）
const WAKE_RESUME_MIN_GAP_MS = 1000;  // 復帰イベント自体の連続発火をまとめる最小間隔
let lastHeartbeatOkMs = 0;            // 直近ハートビートが「成功」した時刻（クールダウン判定用）
let lastWakeResumeMs = 0;             // 直近の復帰通知で即時送信した時刻（連打防止）
let lastWakeResumeReason = '';        // 直近の復帰理由（診断用: idle / focus / online）
let wakeRetryBudget = 0;              // 復帰直後に許す短い再試行の残数
let wakeRetryTimer = null;            // 短い再試行のタイマー（1 本だけ保持）

// GAS の応答（ka_active / sync_interval_sec / idle_drift_until）を storage と同期ループへ反映する。
// 旧形式（真偽値のみ）でも受け付ける（後方互換）。
function applyRemoteKeepalive(payload) {
  let active, intervalSec, driftUntil;
  if (payload && typeof payload === 'object') {
    active = !!payload.ka_active;
    intervalSec = Number(payload.sync_interval_sec);
    driftUntil = Number(payload.idle_drift_until) || 0;
  } else {
    active = !!payload;
    intervalSec = active ? 1.5 : 0;
    driftUntil = active ? 0 : (Date.now() + 30000);
  }
  const newIntervalMs = (active && isFinite(intervalSec) && intervalSec > 0)
    ? Math.round(intervalSec * 1000) : 1500;
  // 非稼働の猶予期限は「一度決めたら延長しない」。GAS は毎応答で now+猶予 を返すため、
  // 毎回上書きすると猶予が終わらず（＝停止しない）・ストレージ書込みが増える。
  // さらに端末と GAS の時計ずれで猶予が不当に延びないよう、猶予は最大 60 秒に丸める
  // （＝「全教員ログアウト後、遅くとも約 60 秒以内に完全停止」を保証する）。
  const IDLE_DRIFT_MAX_MS = 60000;
  const driftCandidate = (idleDriftUntil > Date.now())
    ? idleDriftUntil
    : (driftUntil || (Date.now() + 30000));
  const newDriftUntil = active
    ? 0
    : Math.min(driftCandidate, Date.now() + IDLE_DRIFT_MAX_MS);

  const activeChanged = (active !== keepaliveActive);
  const intervalChanged = (newIntervalMs !== activeIntervalMs);
  const driftChanged = (newDriftUntil !== idleDriftUntil);

  // 状態が変わっていなければ storage 書込み・アラーム再登録を行わない。
  // 稼働中は約 1.5 秒ごとに ka_active=true が返るため、毎回書き込むと無駄な I/O と
  // アラーム再設定が発生し、反映速度のゆらぎ・ログ肥大の原因になる。
  if (!activeChanged && !intervalChanged && !driftChanged) return;

  keepaliveActive = active;
  activeIntervalMs = newIntervalMs;
  idleDriftUntil = newDriftUntil;

  try {
    chrome.storage.local.set({
      keepalive_active: active,
      keepalive_interval_sec: active ? (activeIntervalMs / 1000) : 0,
      keepalive_drift_until: idleDriftUntil
    });
  } catch (e) {}

  if (active) {
    // 稼働中のバックストップ（30 秒アラーム）を確保し、猶予用アラームは不要なので止める。
    if (activeChanged) {
      lastSyncMs = 0;          // 稼働へ切替時は次回 ping で即同期し、素早く反映する
      ensureSyncLoop();        // 稼働中のみアラーム＋setTimeout チェーンを登録
      clearIdleDriftAlarm();
      // 稼働中は通常同期が走るため、低速ポーリングは不要（二重起床を防ぐ）。
      clearSlowPoll();
    } else if (intervalChanged) {
      // 【v1.6.6】GAS が sync_interval_sec を変えた（過負荷バックオフ 4 秒など）とき、
      //   setTimeout チェーンの周期を即座に張り替える（GAS の負荷保護を損なわない）。
      scheduleFastChain();
    }
    // 稼働中は起こしプローブ不要（通常同期が走っているため）。止めて通信を増やさない。
    clearWakeProbe();
  } else {
    // 【v1.6.6】非稼働（ka_active=false）を受けた瞬間に高頻度チェーンを即時停止し、
    //   従来の長周期 chrome.alarms スリープへ戻す（放課後・夜間の無駄な通信をゼロに）。
    clearFastChain();
    if (activeChanged || driftChanged) {
      // 非稼働: 30 秒アラームを止めて無駄な起床を止める。猶予期間だけ再開を確認する。
      stopSyncLoop();
      scheduleIdleDrift();
      // 猶予が尽きた後も「先生が復帰したか」だけは拾えるようにする。
      // 間隔は時間帯で切り替える（平日日中=1分固定／夜間・土日祝=10分）。
      ensureWakeProbe();
      // 【低速ポーリング】予約を保持している／子GASへ割り当て済みの端末だけは、
      //   猶予が尽きた後も 5 分周期で起床させる。これが無いと「教員が管理画面を閉じた
      //   まま新しい予約を作る」ケースで端末が永久に眠り、時間制限タイマーが発動しない。
      if (scheduleInterestActive()) ensureSlowPoll();
      else clearSlowPoll();
    }
  }
}

// ==================== 同期のレート制御 ====================
//  ・稼働中（管理アプリが稼働中）        : 1.5 秒 … 指示を 3 秒以内に反映
//  ・非稼働・猶予期間内                 : 1 秒上限の低頻度で再確認（管理アプリの再起動を拾う）
//  ・非稼働・猶予期間外＋予約/子GASあり : 5 分周期の低速ポーリング（予約の取りこぼし防止）
//  ・非稼働・猶予期間外＋予約も子GASも無: 同期しない（doPost を出さない＝通信負荷ゼロ）
const ACTIVE_SYNC_MS = 1500;
const IDLE_SYNC_MS = 0;         // 非稼働時は 1.5 秒の速いポーリングをしない（0＝常にスキップ）
const IDLE_DRIFT_MS = 1000;     // 猶予期間中の再確認レート上限（1 秒）
const IDLE_DRIFT_ALARM_MIN = 5 / 60; // 猶予期間中の再確認アラーム周期（5 秒）
// 【低速ポーリング】v1.6.4 修正
//   教員コンソールを閉じたまま新しい予約が作られると、従来は端末が完全に眠ってしまい
//   予約が永久に届かなかった（＝時間制限タイマーが実機で発動しない本命の原因）。
//   そこで「予約を保持している端末」と「子GASへ割り当て済みの端末」に限り、
//   非稼働・猶予終了後も 5 分周期で起床して予約の到着を確認する。
//   未割り当てかつ予約ゼロの端末は従来どおり「通信ゼロ」を維持する（無駄な doPost を出さない）。
const SLOW_POLL_MS = 5 * 60 * 1000;
const SLOW_POLL_ALARM = 'schedulePoll';
const SLOW_POLL_ALARM_MIN = 5;
let lastSyncMs = 0;
// 【初回ブートストラップの番人】この Service Worker の生存期間で
//   「一度でも送信を試みたか」。false の間は稼働判定をバイパスして必ず1回送る。
let hasSyncedOnce = false;

/**
 * 「予約を取りこぼせない端末か」を判定する（低速ポーリングの可否）。
 *   教員コンソールを閉じたまま新規予約が作成されても、端末が完全に眠っていると
 *   予約が永久に届かず、時間制限タイマーが実機で発動しない。
 *   そこで次のいずれかに該当する端末だけ、非稼働・猶予終了後も 5 分周期で起床する。
 *     ① 子GASへ割り当て済み（＝親から配られた予約を子GASが保持している）
 *     ② 予約キャッシュ（active / upcoming）を 1 件以上保持している
 *   未割り当てかつ予約ゼロの端末は、従来どおり「通信ゼロ」を維持する。
 *   ※ 単体検証（VM へ関数だけを切り出した環境）では宣言が無い場合があるため typeof で守る。
 */
function scheduleInterestActive() {
  if (typeof shardAssignedCache !== 'undefined' && shardAssignedCache) return true;
  if (typeof scheduleCache !== 'undefined' && scheduleCache && scheduleCache.schedules) {
    const s = scheduleCache.schedules;
    const a = Array.isArray(s.active) ? s.active.length : 0;
    const u = Array.isArray(s.upcoming) ? s.upcoming.length : 0;
    if ((a + u) > 0) return true;
  }
  return false;
}

function maybeSync() {
  const now = Date.now();

  // 【初回ブートストラップ】未同期の端末は keepaliveActive / idleDrift の判定より
  //   先に「必ず1回」送る。教員コンソールを閉じていても、ここで親GASから
  //   assigned_gas_url を取得しないと、以後の子GASへのハートビートが永久に
  //   始まらない（実機で「子GASの実行数がゼロ」になった正体）。
  if (!hasSyncedOnce) {
    hasSyncedOnce = true;
    lastSyncMs = now;
    syncWithGas();
    return;
  }

  // 【v1.6.6】多重トリガーの重複排除。
  //   setTimeout チェーン / chrome.alarms / content.js の KEEPALIVE_PING が
  //   同時に叩いても、通信中の二重送信はここで必ず捨てる（通信量を増やさない）。
  if (syncInFlight) return;

  if (keepaliveActive) {
    // 稼働中: setTimeout チェーンを主軸に sync_interval_sec（1.5 秒／バックオフ 4 秒）へ
    //   厳密追従する。前回「送信開始」から sync_interval_sec × 0.8 秒未満の再トリガーは
    //   重複とみなす（タイマーの 1〜2ms の揺らぎで周期が 2 倍へ落ちるのを防ぐ下限緩和）。
    const fastInterval = activeIntervalMs > 0 ? activeIntervalMs : ACTIVE_SYNC_MS;
    const minGap = Math.max(0, Math.round(fastInterval * FAST_MIN_GAP_RATIO));
    if (lastHeartbeatStartMs > 0) {
      const since = lastHeartbeatStartMs > now ? -1 : (now - lastHeartbeatStartMs);
      if (since >= 0 && since < minGap) return;
    }
    lastSyncMs = now;
    syncWithGas();
    return;
  }

  let interval;
  if (idleDriftUntil && now < idleDriftUntil) {
    interval = IDLE_DRIFT_MS; // 猶予期間のみ低頻度で再確認する
  } else if (scheduleInterestActive()) {
    // 【低速ポーリング】非稼働・猶予終了でも、予約保持または子GAS割り当て済みなら
    //   5 分周期で起床して予約の到着を確認する（時間制限タイマーの取りこぼし防止）。
    interval = SLOW_POLL_MS;
    ensureSlowPoll();
  } else {
    // 非稼働・猶予終了・予約も子GASも無し → 同期しない（doPost を出さない＝通信負荷ゼロ）。
    //   猶予用／低速ポーリング用アラームが残っていれば止める。
    clearIdleDriftAlarm();
    clearSlowPoll();
    return;
  }
  if (now - lastSyncMs < interval) return;
  lastSyncMs = now;
  syncWithGas();
}

/**
 * 稼働中のバックストップ（30 秒アラーム）を登録する。
 * ・稼働中のみ登録する（非稼働時は登録しない＝無駄な起床・doPost を防ぐ）。
 * ・内容スクリプトが無い場合（全タブ閉じ等）でも、これによって同期が継続する。
 */
function ensureSyncLoop() {
  try {
    // 30秒（MV3の最小値）。SW が 30 秒アイドルで停止しても復旧できるフェイルセーフ。
    chrome.alarms.create('syncAlarm', { periodInMinutes: 0.5 });
  } catch (e) {}
  // 【v1.6.6】稼働中は setTimeout チェーンを主軸にする（alarms は 30 秒＋間引きで遅い）。
  scheduleFastChain();
}

/**
 * 稼働中の高精度 setTimeout チェーンを（再）スケジュールする。
 *   sync_interval_sec（通常 1.5 秒／過負荷バックオフ時 4 秒）に厳密追従する。
 *   チェーンは常に 1 本だけ保持し、再設定時は前のタイマーを必ず破棄する。
 */
function scheduleFastChain() {
  clearFastChain();
  if (!keepaliveActive) return;
  const ms = activeIntervalMs > 0 ? activeIntervalMs : ACTIVE_SYNC_MS;
  fastChainTimer = setTimeout(function () {
    fastChainTimer = null;
    if (!keepaliveActive) return; // 稼働が終わっていたら再武装しない
    maybeSync();
    scheduleFastChain();
  }, ms);
}

/** 高精度チェーンを停止する（非稼働へ戻った瞬間に呼ぶ）。 */
function clearFastChain() {
  if (fastChainTimer) {
    try { clearTimeout(fastChainTimer); } catch (e) {}
    fastChainTimer = null;
  }
}

/** 稼働が終わったらバックストップ（30 秒アラーム）と高頻度チェーンを止める。 */
function stopSyncLoop() {
  try { chrome.alarms.clear('syncAlarm'); } catch (e) {}
  clearFastChain();
}

/**
 * 稼働→非稼働へ切り替わった直後の「猶予期間」だけ、低頻度で再開を確認するアラームを登録する。
 * 猶予（GAS が idle_drift_until で指定）を過ぎたら自動的に止まるため、無駄な通信は残らない。
 */
function scheduleIdleDrift() {
  const remaining = idleDriftUntil - Date.now();
  if (remaining <= 0) { clearIdleDriftAlarm(); return; }
  const periodMin = IDLE_DRIFT_ALARM_MIN;
  try {
    chrome.alarms.create('idleDriftAlarm', {
      delayInMinutes: Math.min(periodMin, remaining / 60000),
      periodInMinutes: periodMin
    });
  } catch (e) {}
}

/** 猶予期間用の再確認アラームを止める。 */
function clearIdleDriftAlarm() {
  try { chrome.alarms.clear('idleDriftAlarm'); } catch (e) {}
}

/**
 * 低速ポーリング用アラーム（5 分周期）を登録する。
 *   教員コンソールが閉じられていても、予約を持つ端末は 5 分ごとに起床して
 *   親／子GASへハートビートを送り、新規予約を受け取る。
 *   MV3 の Service Worker は 30 秒で停止するため、アラームが唯一の継続手段になる。
 *   ※ 既に登録済みでも chrome.alarms.create は同名を上書きするため冪等。
 */
function ensureSlowPoll() {
  try {
    chrome.alarms.create(SLOW_POLL_ALARM, { periodInMinutes: SLOW_POLL_ALARM_MIN });
  } catch (e) {}
}

/** 低速ポーリング用アラームを止める（予約も子GAS割り当ても無くなったとき）。 */
function clearSlowPoll() {
  try { chrome.alarms.clear(SLOW_POLL_ALARM); } catch (e) {}
}

// ==================== 非稼働時の「起こしプローブ」 ====================
// 課題: 非稼働になると端末は同期を完全に止めるため、先生が再ログインしても
//       端末が眠ったままでオンラインにならず、ロック・URL配信も届かなかった。
//       「蓋を閉じて開いただけ」では onStartup もタブ生成も起きないため復帰できない。
// 方針: 通信負荷を増やさないことを最優先に、二段構えで復帰させる。
//   ① イベント起床（通信ゼロ）… 蓋を開けた/操作再開（chrome.idle）で 1 回だけ同期。
//   ② 時間帯で間隔を変えるプローブ … ①で拾えない場合に備え、シートに触らない
//      軽量な wake_check だけを送る。間隔は「学校の稼働時間」に合わせて切り替える。
//       ・平日 08:00〜17:00 … 1 分固定（バックオフしない＝ログイン後すぐ復帰）
//       ・上記以外（17:00以降・土日・祝日）… 10 分（バッテリー保護・ログ削減）
//      先生が復帰していれば（ka_active か wake_epoch の変化）即座に通常同期へ戻る。
//
// ※ 13 校は校ごとに Google アカウント／スプレッドシート／GAS を独立分離しているため、
//    1 アカウントあたりの負荷余裕は大きい。日中の 1 分固定はその前提に基づく。
const WAKE_ALARM_NAME = 'wakeAlarm';

// ---- 時間帯の定義（日本時間で判定する。端末のタイムゾーン設定に依存させない）----
const JST_OFFSET_MS = 9 * 60 * 60 * 1000; // UTC+9
const PROBE_DAY_START_HOUR = 8;   // 平日の開始時刻（この時刻から日中扱い）
const PROBE_DAY_END_HOUR = 17;    // 平日の終了時刻（この時刻から夜間扱い）
const PROBE_DAY_MIN = 1;          // 平日日中：1 分固定
const PROBE_NIGHT_MIN = 10;       // 夜間・土日祝：10 分（0 にすると停止）

/** その月の第 n 曜日の日付を返す（nth は 1 始まり）。 */
function nthWeekdayOfMonth(year, month, weekday, nth) {
  const first = new Date(Date.UTC(year, month - 1, 1));
  const firstDow = first.getUTCDay();
  return 1 + ((weekday - firstDow + 7) % 7) + (nth - 1) * 7;
}

/** 春分／秋分の日（近似式。1948〜2150 年で有効）。 */
function equinoxDay(year, isSpring) {
  const base = isSpring ? 20.8431 : 23.2488;
  const v = base + 0.242194 * (year - 1980) - Math.floor((year - 1980) / 4);
  return Math.floor(v);
}

/**
 * その年の日本の祝日（振替休日・国民の休日を含む）を "月-日" の集合で返す。
 * 祝日判定は端末内で完結させる（外部通信しない＝通信負荷ゼロ）。
 */
function japaneseHolidaySet(year) {
  const set = {};
  const add = (m, d) => { if (d >= 1 && d <= 31) set[m + '-' + d] = true; };

  add(1, 1);                                            // 元日
  add(1, nthWeekdayOfMonth(year, 1, 1, 2));             // 成人の日（第2月曜）
  add(2, 11);                                           // 建国記念の日
  add(2, 23);                                           // 天皇誕生日
  add(3, equinoxDay(year, true));                       // 春分の日
  add(4, 29);                                           // 昭和の日
  add(5, 3); add(5, 4); add(5, 5);                      // 憲法記念日／みどりの日／こどもの日
  add(7, nthWeekdayOfMonth(year, 7, 1, 3));             // 海の日（第3月曜）
  add(8, 11);                                           // 山の日
  add(9, nthWeekdayOfMonth(year, 9, 1, 3));             // 敬老の日（第3月曜）
  add(9, equinoxDay(year, false));                      // 秋分の日
  add(10, nthWeekdayOfMonth(year, 10, 1, 2));           // スポーツの日（第2月曜）
  add(11, 3);                                           // 文化の日
  add(11, 23);                                          // 勤労感謝の日

  // 振替休日: 日曜に当たる祝日は、翌日以降で最初の「祝日でない日」が休日になる。
  const base = {};
  Object.keys(set).forEach(k => { base[k] = true; });
  Object.keys(base).forEach(k => {
    const p = k.split('-');
    const m = Number(p[0]), d = Number(p[1]);
    const dt = new Date(Date.UTC(year, m - 1, d));
    if (dt.getUTCDay() !== 0) return;
    let cur = new Date(Date.UTC(year, m - 1, d));
    for (let i = 0; i < 10; i++) {
      cur = new Date(cur.getTime() + 86400000);
      const key = (cur.getUTCMonth() + 1) + '-' + cur.getUTCDate();
      if (!base[key]) { set[key] = true; break; }
    }
  });

  // 国民の休日: 祝日に挟まれた 1 日（例: 敬老の日と秋分の日に挟まれた 9/22）。
  Object.keys(base).forEach(k => {
    const p = k.split('-');
    const m = Number(p[0]), d = Number(p[1]);
    const mid = m + '-' + (d + 1);
    const nxt = m + '-' + (d + 2);
    if (base[mid] || set[mid]) return;
    if (base[nxt] && d + 2 <= 31) set[mid] = true;
  });

  return set;
}

// 年の祝日集合は使い回す（毎回作り直すと無駄）。
let holidayCacheYear = 0;
let holidayCacheSet = null;

/** 指定日が日本の祝日かどうか。 */
function isJapaneseHoliday(year, month, day) {
  if (holidayCacheYear !== year || !holidayCacheSet) {
    holidayCacheSet = japaneseHolidaySet(year);
    holidayCacheYear = year;
  }
  return !!holidayCacheSet[month + '-' + day];
}

/** 指定時刻（エポックms）が「日中（平日8:00-17:00）か」を日本時間で判定する。 */
function probeBandState(nowMs) {
  const j = new Date(nowMs + JST_OFFSET_MS);
  const y = j.getUTCFullYear();
  const mo = j.getUTCMonth() + 1;
  const d = j.getUTCDate();
  const h = j.getUTCHours();
  const dow = j.getUTCDay();
  const holiday = isJapaneseHoliday(y, mo, d);
  const weekend = (dow === 0 || dow === 6);
  const dayTime = (h >= PROBE_DAY_START_HOUR) && (h < PROBE_DAY_END_HOUR);
  return { inDay: (!weekend && !holiday && dayTime), weekend: weekend, holiday: holiday };
}

/**
 * 現在の時間帯から「プローブ間隔（分）」と「次の時間帯境界までの分」を求める。
 * 戻り値: { inDay, weekend, holiday, minutes, minutesUntilChange }
 */
function getProbeBand(nowMs) {
  const t = (typeof nowMs === 'number' && isFinite(nowMs)) ? nowMs : Date.now();
  const cur = probeBandState(t);

  // 次の境界（inDay が反転する時刻）を 1 分刻みで探す。
  // 日本には夏時間が無いため、1 分 = 60000ms で厳密に数えられる。
  const MAX_STEPS = 60 * 24 * 8;
  let step = 0;
  while (step < MAX_STEPS) {
    step++;
    if (probeBandState(t + step * 60000).inDay !== cur.inDay) break;
  }

  return {
    inDay: cur.inDay,
    weekend: cur.weekend,
    holiday: cur.holiday,
    minutes: cur.inDay ? PROBE_DAY_MIN : PROBE_NIGHT_MIN,
    minutesUntilChange: Math.max(0.5, step)
  };
}

/**
 * 起こしプローブを「現在の時間帯」の間隔で登録する。
 * 次の時間帯境界が来る前に一度起きるよう delay を短くするので、
 * 8:00 や 17:00 の切り替わりに最大でも境界時刻ちょうどで間隔が更新される。
 */
function ensureWakeProbe() {
  const band = getProbeBand(Date.now());
  if (!band.minutes || band.minutes <= 0) { clearWakeProbe(); return; } // 0 = 停止
  const delay = Math.min(band.minutes, band.minutesUntilChange);
  try {
    chrome.alarms.create(WAKE_ALARM_NAME, {
      delayInMinutes: delay,
      periodInMinutes: band.minutes
    });
  } catch (e) {}
}

/** 起こしプローブを止める（稼働中は不要なため）。 */
function clearWakeProbe() {
  try { chrome.alarms.clear(WAKE_ALARM_NAME); } catch (e) {}
}

/**
 * 「先生が復帰したか」だけを軽く確認する。
 * シートに触らない wake_check を使うため、GAS 側の実行はごく短時間で終わる。
 * 復帰を検知したら、その場で通常のハートビート（＝詳細なオンライン通知）を送り、
 * 端末一覧に即座にオンラインとして現れるようにする。
 */
async function probeWake() {
  if (keepaliveActive) { clearWakeProbe(); return; } // 既に稼働中なら何もしない
  try {
    const data = await chrome.storage.local.get(null);
    const gasUrl = resolveGasUrl(data);
    if (!gasUrl) return;

    const controller = (typeof AbortController !== 'undefined') ? new AbortController() : null;
    let timer = null;
    if (controller) {
      timer = setTimeout(() => { try { controller.abort(); } catch (e) {} }, 8000);
    }
    let res;
    try {
      res = await fetch(gasUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
        body: JSON.stringify({ action: 'wake_check' }),
        redirect: 'follow',
        signal: controller ? controller.signal : undefined
      });
    } finally {
      if (timer) clearTimeout(timer);
    }
    if (!res || !res.ok) return;

    const j = await res.json();
    if (!j || !j.success) return;

    const epoch = Number(j.wake_epoch) || 0;
    const seen = Number(data.wake_epoch_seen) || 0;

    // 「先生がログインしている」または「緊急呼び出しフラグが更新された」→ 起こす
    if (j.ka_active || (epoch && epoch !== seen)) {
      if (epoch) await chrome.storage.local.set({ wake_epoch_seen: epoch });
      // 稼働状態へ切り替える（ensureSyncLoop が 30 秒アラームを張る）
      applyRemoteKeepalive({
        ka_active: !!j.ka_active,
        sync_interval_sec: j.sync_interval_sec,
        idle_drift_until: j.idle_drift_until
      });
      // 詳細なオンライン通知（doPost）。これが「最終同期日時」を更新し、
      // 端末一覧にオンラインとして表示される。
      lastSyncMs = 0;
      syncWithGas();
      return;
    }

    // 復帰していない → その時点の時間帯に応じた間隔で次回を待つ。
    // （平日日中は 1 分、夜間・土日祝は 10 分。境界をまたぐと自動で切り替わる）
    if (epoch) await chrome.storage.local.set({ wake_epoch_seen: epoch });
    ensureWakeProbe();
  } catch (e) {}
}

/**
 * 【v1.6.7】復帰通知の短い再試行タイマーを止める。
 */
function clearWakeRetry() {
  if (wakeRetryTimer) {
    try { clearTimeout(wakeRetryTimer); } catch (e) {}
    wakeRetryTimer = null;
  }
}

/**
 * 【v1.6.7】Wi-Fi 再接続待ちのための「短い再試行」を 1 回だけ予約する。
 *   蓋を開けた直後は Wi-Fi の再接続に 1〜2 秒かかるため、初回通信が
 *   `Failed to fetch` 等で落ちる。ここで長いエラーバックオフ（30 秒〜数分）へ
 *   入ってしまうと「オンライン復帰が遅い」実害になるので、2 秒後に短く再試行する。
 *   予算（wakeRetryBudget）は復帰通知のたびに WAKE_RETRY_MAX へ戻し、
 *   通常のエラー時は 0 のままなので無駄な通信は増えない。
 *   戻り値: 予約したら true / 予算切れ・通信中なら false
 */
function scheduleWakeRetry() {
  if (wakeRetryBudget <= 0) return false;
  wakeRetryBudget--;
  clearWakeRetry();
  wakeRetryTimer = setTimeout(function () {
    wakeRetryTimer = null;
    if (syncInFlight) return; // 別の同期が走っているなら次周期に任せる（二重送信しない）
    lastSyncMs = 0;
    syncWithGas();
  }, WAKE_RETRY_DELAY_MS);
  return true;
}

/**
 * 【v1.6.7】スリープ復帰（蓋を開けた／画面ロック解除／ネットワーク復帰）の即時ハートビート。
 *   ・トリガー: chrome.idle.onStateChanged('active') / chrome.windows.onFocusChanged /
 *               Service Worker の online イベント
 *   ・クールダウン: 「前回の【成功】送信から 5 秒」未満なら捨てる。
 *     これにより稼働中の通常のウィンドウ切替（1.5 秒ごとに成功している状態）では
 *     一切追加の通信が発生しない。
 *   ・既存の syncInFlight 排他制御と併用し、通信中の復帰通知も捨てる。
 *   戻り値: 実際に即時送信を発火したら true
 */
function handleWakeResume(reason) {
  const now = Date.now();
  if (syncInFlight) return false; // 通信中は捨てる（多重送信しない）
  // 短時間の連続発火（フォーカス往復・イベントの重複配送）をまとめて捨てる。
  if (lastWakeResumeMs > 0 && (now - lastWakeResumeMs) < WAKE_RESUME_MIN_GAP_MS) return false;
  // クールダウン: 前回の「成功」から一定時間経っていないなら即時送信しない。
  if (lastHeartbeatOkMs > 0 && (now - lastHeartbeatOkMs) < WAKE_RESUME_COOLDOWN_MS) return false;
  lastWakeResumeMs = now;
  clearWakeRetry();                 // 予約済みの再試行は今回の送信に吸収する
  wakeRetryBudget = WAKE_RETRY_MAX; // 復帰直後だけ短い再試行を許可する
  lastSyncMs = 0;                   // レート制限を無視して必ず 1 回同期する
  syncWithGas();
  if (reason) lastWakeResumeReason = String(reason);
  return true;
}

// ① イベント起床: 蓋を開けた／スリープから復帰して操作を再開した瞬間に 1 回だけ同期する。
//    アラームと違い「実際に人が端末を使ったとき」しか動かないため、通信は増えない。
//    （これが無いと、蓋の開閉だけでは SW が起きず復帰できなかった）
//    v1.6.7: クールダウン（成功から 5 秒）付きの handleWakeResume に一本化した。
try {
  if (chrome.idle && chrome.idle.onStateChanged) {
    chrome.idle.setDetectionInterval(60);
    chrome.idle.onStateChanged.addListener((state) => {
      if (state !== 'active') return;
      handleWakeResume('idle');
    });
  }
} catch (e) {}

// ② 【v1.6.7】ネットワーク復帰（Wi-Fi 再接続）の瞬間も即時同期する。
//    Chromebook の蓋を開けた直後は Wi-Fi がまだ繋がっておらず、少し遅れて online になる。
//    その瞬間に送れば「数秒でオンライン復帰」が成立する（クールダウンは共通）。
try {
  if (typeof self !== 'undefined' && self && self.addEventListener) {
    self.addEventListener('online', function () { handleWakeResume('online'); });
  }
} catch (e) {}

// SW が停止状態から復帰したとき（端末が眠ったまま SW だけ再起動した場合）に備え、
// 非稼働なら起こしプローブを張り直す。これが無いとアラームが失われたまま復帰できない。
try {
  chrome.storage.local.get(['keepalive_active', 'keepalive_interval_sec'], (d) => {
    if (chrome.runtime.lastError) return;
    if (d && d.keepalive_active) {
      // 【v1.6.6】SW が 30 秒アイドルで停止した直後の復帰。
      //   稼働中だったなら setTimeout チェーンとフェイルセーフ alarm を即座に張り直す
      //   （これが無いと alarms の 30 秒待ちまで遅延が残る）。
      keepaliveActive = true;
      const sec = Number(d.keepalive_interval_sec);
      if (isFinite(sec) && sec > 0) activeIntervalMs = Math.round(sec * 1000);
      hasSyncedOnce = true;
      lastSyncMs = 0;
      ensureSyncLoop();
    } else {
      ensureWakeProbe();
    }
  });
} catch (e) {}

/**
 * 停止後に管理アプリ（教員コンソール）が再度開かれた場合の復帰。
 * コンソールは GAS の Web アプリ（script.google.com/macros/...）で開かれるため、
 * そのタブ作成/更新を検知して一度だけ通常同期を走らせ、ka_active=true を確認できれば
 * 稼働中の速い同期へ復帰する。＝停止中でもコンソールを開けば数秒以内に拡張が再稼働する。
 */
function resumeFromConsoleTab(url) {
  if (keepaliveActive) return; // 既に稼働中なら何もしない
  const u = String(url || '');
  if (!/^https?:\/\/script\.google\.com\//i.test(u)) return;
  lastSyncMs = 0;
  syncWithGas();
}


/**
 * 教員コンソールの稼働を GAS に通知する（ログイン中に 30 秒ごとに呼ばれる）。
 * 児童端末はハートビート応答の ka_active で稼働を検知し、同期周期を切り替える。
 */
async function consoleTouch() {
  try {
    const data = await chrome.storage.local.get(null);
    const gasUrl = resolveGasUrl(data);
    if (!gasUrl) return false;
    const res = await fetch(gasUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify({ action: 'console_touch' }),
      redirect: 'follow'
    });
    return res.ok;
  } catch (e) { return false; }
}

/** 教員コンソールの稼働を解除する（ログアウト時）。 */
async function consoleRelease() {
  try {
    const data = await chrome.storage.local.get(null);
    const gasUrl = resolveGasUrl(data);
    if (!gasUrl) return false;
    const res = await fetch(gasUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify({ action: 'console_release' }),
      redirect: 'follow'
    });
    return res.ok;
  } catch (e) { return false; }
}

// 管理コンソールからのポリシー変更検知 (chrome.storage.managed の動的更新)
if (chrome.storage && chrome.storage.onChanged) {
  chrome.storage.onChanged.addListener(async (changes, areaName) => {
    if (areaName === 'managed') {
      console.log('[EduAgent] 管理コンソールからのポリシー更新を受信しました');
      await initializeClient();
    }
  });
}

/**
 * 端末クライアントの初期化処理
 * Googleアカウントの自動検出・Managedポリシー適用・即時自動同期
 */
async function initializeClient() {
  try {
    const stored = await chrome.storage.local.get(null);
    const managed = await getManagedPolicy();
    const googleAccount = await getStudentIdentity();

    // 児童IDの決定優先度:
    // 1. 管理コンソールポリシー指定（${USER_EMAIL} マクロ または 直接指定）
    // 2. Chromebookログイン中のGoogleアカウント（chrome.identity）
    // 3. 既存の保存ID
    // 4. ランダム生成ID
    let studentId = stored.student_id || '';
    if (managed.student_id && managed.student_id.trim() && managed.student_id.trim() !== '${USER_EMAIL}') {
      studentId = managed.student_id.trim();
    } else if (googleAccount) {
      studentId = googleAccount;
    } else if (!studentId) {
      studentId = 'student_' + Math.random().toString(36).substring(2, 8);
    }

    // GAS WebアプリURLの決定優先度:
    // 1. 管理コンソールポリシー指定
    // 2. 既存の保存URL
    let gasUrl = stored.gas_url || '';
    if (managed.gas_url && managed.gas_url.trim()) {
      gasUrl = managed.gas_url.trim();
    }

    // 学校名 → GAS URL のマッピング（1つの拡張機能で13校のGASへ振り分け）。
    // 管理コンソールポリシー（gas_url_map）を優先し、無ければ保存済みを使う。
    let gasUrlMap = (stored.gas_url_map && typeof stored.gas_url_map === 'object') ? stored.gas_url_map : {};
    if (managed.gas_url_map && typeof managed.gas_url_map === 'object') {
      gasUrlMap = managed.gas_url_map;
    }

    const initialData = {
      ...DEFAULT_CONFIG,
      ...stored,
      student_id: studentId,
      gas_url: gasUrl,
      gas_url_map: gasUrlMap,
      google_account: googleAccount || ''
    };

    // 管理ポリシーの school_name は学校OUごとに配布されるため最優先。
    // 保存済みが「未設定」のままでも、ポリシー値で上書きする。
    const managedSchool = String(managed.school_name || '').trim();
    if (managedSchool && managedSchool !== '未設定') {
      initialData.school_name = managedSchool;
    } else {
      initialData.school_name = pickMeaningfulSchoolName(initialData.school_name);
    }

    await chrome.storage.local.set(initialData);

    // 学校に対応するGAS URLを解決（マッピング優先、無ければ gas_url）
    const initialGasUrl = resolveGasUrl(initialData);

    // 稼働判定は GAS 応答（ka_active）で行う。初期同期を 1 回実行し、稼働中なら
    // applyRemoteKeepalive が 30 秒アラームのバックストップを登録する
    // （非稼働ならアラームを登録しない＝無駄な起床・doPost を防ぐ）。
    console.log(`[EduAgent] 児童端末セットアップ完了 (児童ID: ${studentId})`);

    // GAS URLが設定されていれば即座に自動同期を実行！
    if (initialGasUrl) {
      hasSyncedOnce = true; // 初回同期を実行済み（maybeSync の二重発火を防ぐ）
      await syncWithGas();
    } else {
      // 【無言停止の根絶】URL が無い＝端末は1件も送信できない。
      //   旧実装はここで何も出さずに終わっていたため、
      //   「実行数ゼロ・エラーも出ない」という最悪の切り分け不能状態になった。
      console.warn('[EduAgent] GAS WebアプリURLが未設定のため同期できません。'
        + ' 管理ポリシーの gas_url / gas_url_map を配布するか、'
        + ' background.js の DEFAULT_GAS_URL に親GASの /exec を設定してください。');
      await recordSyncDiag(false, 'no_gas_url',
        'GAS WebアプリURLが未設定です（管理ポリシーの gas_url / gas_url_map、'
        + ' または background.js の DEFAULT_GAS_URL を設定してください）');
    }

    // 【フェーズ3】保存済みの予約から制限状態と境界アラームを復元する。
    //   chrome.alarms は再起動で消えるため、これが無いと
    //   「翌朝、予約が効かない」「終了時刻を過ぎても解除されない」事故になる。
    //   syncWithGas の後に呼ぶ（新しい予約を取り込んだ直後の状態で張り直すため）。
    await restoreSchedulesOnBoot();
  } catch (err) {
    console.error('[EduAgent] 初期化エラー:', err);
  }
}

/**
 * Google アカウントの自動取得 (chrome.identity)
 */
async function getStudentIdentity() {
  return new Promise((resolve) => {
    if (chrome.identity && chrome.identity.getProfileUserInfo) {
      chrome.identity.getProfileUserInfo({ accountStatus: 'ANY' }, (userInfo) => {
        if (chrome.runtime.lastError || !userInfo || !userInfo.email) {
          resolve(null);
        } else {
          resolve(userInfo.email.trim().toLowerCase());
        }
      });
    } else {
      resolve(null);
    }
  });
}

/**
 * Google 管理コンソールからの配布ポリシー取得 (chrome.storage.managed)
 */
async function getManagedPolicy() {
  return new Promise((resolve) => {
    if (chrome.storage && chrome.storage.managed) {
      chrome.storage.managed.get(null, (items) => {
        if (chrome.runtime.lastError || !items) {
          resolve({});
        } else {
          resolve(items);
        }
      });
    } else {
      resolve({});
    }
  });
}

/**
 * 学校名の表記ゆれ（前後空白・全角スペース・市立等の接頭辞・全角英数字）を吸収する正規化。
 * gas_url_map のキー照合に使用する。
 */
function normalizeSchoolKey(name) {
  return String(name || '')
    .replace(/[\u3000\s]+/g, '')
    .replace(/[（）()]/g, '')
    .replace(/[０-９]/g, function (c) { return String.fromCharCode(c.charCodeAt(0) - 0xFEE0); })
    .replace(/[Ａ-Ｚａ-ｚ]/g, function (c) { return String.fromCharCode(c.charCodeAt(0) - 0xFEE0); })
    .toUpperCase()
    .replace(/^美作市立/, '').replace(/^美作市/, '').replace(/^市立/, '').replace(/^公立/, '')
    .trim();
}

/**
 * 端末に保存・送信する学校名を決める（複数候補から最初の「意味のある値」を採用）。
 *
 * GAS 側のスプレッドシートは、教員が管理画面で紐付けるまで学校名を「未設定」で返す。
 * その「未設定」をそのまま採用すると、管理ポリシーで配布した school_name が
 * 毎回上書きされて失われ、端末から GAS へ学校名を送れなくなる。
 * そのため '' と '未設定' は「値なし」として読み飛ばす。
 */
function pickMeaningfulSchoolName() {
  for (let i = 0; i < arguments.length; i++) {
    const v = String(arguments[i] || '').trim();
    if (v && v !== '未設定') return v;
  }
  return '未設定';
}

/**
 * 1つの拡張機能で複数校（13校）のGASへ振り分けるためのGAS URL解決。
 * 優先度:
 *   1. gas_url_map[学校名]  … 学校ごとに別のGAS（スプレッドシート）を使う場合（推奨）
 *      ※ 表記ゆれ（「英田小」「美作市立英田小学校」等）を吸収して照合する
 *   2. gas_url              … 単一校／共通のGASを使う場合（後方互換）
 *   3. ''                   … 未設定
 * 学校名が未確定（未設定）の場合は gas_url にフォールバックする。
 */
function resolveGasUrl(data) {
  const map = (data && data.gas_url_map && typeof data.gas_url_map === 'object') ? data.gas_url_map : {};
  const school = String((data && data.school_name) || '').trim();
  const direct = String((data && data.gas_url) || '').trim();

  // 子GAS分散（SHARD_MODE）: 親から割り当てられた子GASがあれば、それを最優先で使う。
  // これが無い場合（＝従来運用・SHARD_MODE 無効）は、以下の学校名ベースの解決に進む。
  const assigned = String((data && data.assigned_gas_url) || '').trim();
  if (assigned) return assigned;

  if (school && school !== '未設定') {
    // 完全一致
    if (map[school] && String(map[school]).trim()) return String(map[school]).trim();
    // 表記ゆれを吸収した一致
    const norm = normalizeSchoolKey(school);
    const keys = Object.keys(map);
    for (let i = 0; i < keys.length; i++) {
      if (normalizeSchoolKey(keys[i]) === norm && String(map[keys[i]]).trim()) {
        return String(map[keys[i]]).trim();
      }
    }
  }
  // 4) 最後の砦: 埋め込みの既定（親GASの /exec）。
  //   Managed Storage ポリシー未配布の端末はここが唯一の通信先になる。
  //   これが空だと端末は1件も送信できないため、呼び出し側で必ず診断を残す。
  //   typeof ガードは、この関数だけを単体で切り出して検証するテスト環境
  //   （DEFAULT_GAS_URL を注入しない sandbox）でも ReferenceError にしないため。
  const embedded = (typeof DEFAULT_GAS_URL === 'string') ? DEFAULT_GAS_URL.trim() : '';
  return direct || embedded;
}

// ==================== 子GAS分散（SHARD_MODE）: 動的ルーティング ====================
// 1校240台 × 1.5秒周期 ≒ 160 req/秒 を 1 つの GAS で受けると、GAS の
// 「同時実行 30/ユーザー」に達する。そこで親GASが端末のクラスから子GASを割り当て、
// 端末は以後その子GASへ直接ハートビートする（親は割り当ての指示だけを出す）。
//
// 【端末側の状態】
//   assigned_gas_url   … 割り当てられた子GASのURL（空＝親に繋ぐ）
//   assigned_from      … 割り当てを出した親のURL（再確認・切り戻し先）
//   assigned_at        … 割り当てを受けた時刻（エポックms）
//   assigned_class     … 割り当ての根拠になったクラス（表示・診断用）
//   assigned_fail_count… 子GASへの連続失敗回数（閾値で親へ戻す）
const SHARD_RECHECK_MS = 6 * 60 * 60 * 1000; // 6時間ごとに親へ再確認（クラス変更に追従）
const SHARD_FAIL_LIMIT = 3;                  // 子GASへ3回連続で失敗したら親へ戻す
const SHARD_COOLDOWN_MS = 30 * 60 * 1000;    // 切り戻し後30分は再割り当てを受けない（失敗の無限往復を防ぐ）

// 割り当て状態のメモリ上の写し。
//   同期の先頭で storage.local.get(null) を 1 回読んでいるので、その値で初期化する。
//   これにより 1.5 秒ごとの判定で余分なストレージ読み取りを行わない。
let shardAssignedCache = '';
let shardFailCount = 0;

// 【バトンタッチ（即時ハートビート）】v1.6.4 修正
//   親GASから新しい assigned_gas_url（子GAS）を受け取った直後は、端末の通信先が
//   親→子へ切り替わった第1報で終わってしまい、子GAS側には「端末が存在する」ことも
//   「予約を配るべき相手」であることも一切伝わっていなかった（実機で子GASの実行数ゼロ）。
//   そこで「割り当てが確定した」ことをこのフラグで1回だけ持ち越し、syncWithGas() の
//   finally（＝syncInFlight のガード解放直後）で消費して子GAS宛てに2回目の同期を発火する。
//   ※ フラグは必ず消費時に false へ戻すため、子GASが assigned_gas_url を返さないことも
//     相まって無限再入にはならない（1割り当てにつき1回限りのバトンタッチ）。
let shardHandoffPending = false;

function shardAssignedUrl(data) {
  return String((data && data.assigned_gas_url) || '').trim();
}

/** 同期の先頭で読み込んだ data から、割り当て状態のメモリ写しを作る。 */
function shardSyncMemory(data) {
  shardAssignedCache = shardAssignedUrl(data);
  shardFailCount = Number((data && data.assigned_fail_count) || 0) || 0;
}

/**
 * 親の応答に含まれる assigned_gas_url を保存し、次回以降の通信先を切り替える。
 * 子GASは assigned_gas_url を返さないため、子と通信している間は割り当てが維持される。
 * 親と通信していて assigned_gas_url が返らない場合は、分散が無効化されたとみなして
 * 割り当てを捨てる（子GASを廃止したときに端末が取り残されないようにする）。
 *
 * ※ talkingToParent のときは、値が変わらなくても assigned_at を更新する。
 *   これが無いと「6時間経過」の条件が永久に真になり、以後ずっと親へ送り続けてしまう。
 */
async function applyShardAssignment(resJson, data, usedUrl, talkingToParent) {
  const next = String((resJson && resJson.assigned_gas_url) || '').trim();
  const cur = shardAssignedUrl(data);
  const patch = {};

  if (next) {
    // 切り戻し直後のクールダウン中は再割り当てを受けない。
    const fbAt = Number((data && data.shard_fallback_at) || 0);
    if (!cur && fbAt && (Date.now() - fbAt) < SHARD_COOLDOWN_MS) return;

    if (next !== cur || talkingToParent) {
      patch.assigned_gas_url = next;
      patch.assigned_at = Date.now(); // 変更なしでも再確認時刻を更新（B1 の修正）
      patch.assigned_class = String((resJson && resJson.assigned_class) || '');
      patch.assigned_fail_count = 0;
      if (talkingToParent) patch.assigned_from = String(usedUrl || '');
      else if (!cur) patch.assigned_from = String((data && data.assigned_from) || '');
      if (data && data.shard_fallback) patch.shard_fallback = false;
      if (fbAt) patch.shard_fallback_at = 0;
    }
  } else if (talkingToParent && cur) {
    // 親が割り当てを返さない＝SHARD_MODE 無効／マップ削除。親へ戻す。
    patch.assigned_gas_url = '';
    patch.assigned_at = 0;
    patch.assigned_class = '';
    patch.assigned_from = '';
    patch.assigned_fail_count = 0;
  }

  if (Object.keys(patch).length) {
    try { await chrome.storage.local.set(patch); } catch (e) {}
    shardAssignedCache = String(patch.assigned_gas_url || '');
    shardFailCount = 0;

    // 【バトンタッチ】新しい子GAS URL を保存した瞬間に「2通目を送る」意図を立てる。
    //   ここで直接 syncWithGas() を呼ぶと、呼び出し元の syncWithGas() がまだ
    //   syncInFlight=true のためガードに弾かれて**無言で捨てられる**（実機で子GASの
    //   実行数がゼロだった原因そのもの）。フラグに留め、ガード解放後に発火させる。
    //   ※ 空文字（＝親へ切り戻し）では立てない。子GASへ送る意味がないため。
    if (patch.assigned_gas_url) shardHandoffPending = true;
  }
}

/**
 * 子GASへの同期結果を数え、連続失敗が閾値に達したら割り当てを捨てて親へ戻す。
 * 子GASのURL誤り・デプロイ漏れ・共有シークレット相違などで端末が孤立するのを防ぐ。
 *
 * ※ 未割り当て（従来運用・SHARD_MODE 無効）のときは何もせず、ストレージも読まない。
 */
async function noteShardOutcome(ok) {
  try {
    if (!shardAssignedCache) return;
    if (ok) {
      if (shardFailCount !== 0) {
        shardFailCount = 0;
        await chrome.storage.local.set({ assigned_fail_count: 0 });
      }
      return;
    }
    shardFailCount += 1;
    if (shardFailCount >= SHARD_FAIL_LIMIT) {
      shardAssignedCache = '';
      shardFailCount = 0;
      await chrome.storage.local.set({
        assigned_gas_url: '', assigned_at: 0, assigned_class: '',
        assigned_from: '', assigned_fail_count: 0,
        shard_fallback: true, shard_fallback_at: Date.now()
      });
    } else {
      await chrome.storage.local.set({ assigned_fail_count: shardFailCount });
    }
  } catch (e) {}
}

// 同期の多重実行ガード。
// ・syncInterval(1.5秒)より GAS 応答が遅い場合、複数の同期が重なって走る。
// ・古いリクエストの応答が新しい応答の後に到着すると、古い状態（例: ロック解除前）で
//   上書きされ、ロック画面が「消えたり出たり」するちらつきの原因になる。
// ・実行中はスキップし、常に1本だけ直列で走らせる。
const SYNC_TIMEOUT_MS = 12000; // GAS 応答のタイムアウト。ハングで syncInFlight が立ったまま（＝反映停止）になるのを防ぐ。
let syncInFlight = false;

// 同期結果の診断情報。
//   直接読み込み版（検証用）のポップアップは chrome://extensions が使えない環境で
//   「なぜ同期できないのか」を表示する唯一の窓口になるため、失敗理由を保持する。
//   通信負荷を増やさないため、書き込みは「成功可否・理由が変わったときだけ」に限定する。
let lastSyncDiag = { ok: null, code: '', message: '', at: '' };
async function recordSyncDiag(ok, code, message) {
  const at = new Date().toLocaleTimeString();
  const changed = (lastSyncDiag.ok !== ok) || (lastSyncDiag.code !== code) ||
                  (lastSyncDiag.message !== message);
  lastSyncDiag = { ok: !!ok, code: String(code || ''), message: String(message || ''), at: at };
  // 子GAS分散: 子へ連続失敗したら親へ戻す（変化の有無に関わらず毎回判定する）
  try { await noteShardOutcome(!!ok); } catch (e) {}
  if (!changed) return; // 変化なし＝ストレージ書込みしない（I/O を増やさない）
  try {
    await chrome.storage.local.set({
      sync_diag_ok: lastSyncDiag.ok,
      sync_diag_code: lastSyncDiag.code,
      sync_diag_message: lastSyncDiag.message,
      sync_diag_at: lastSyncDiag.at
    });
  } catch (e) {}
}

// 疎通確認（手動実行のみ・通常運用では呼ばれない）。
//   直接読み込み版の検証で「URL が正しいか」「Web アプリの公開範囲が正しいか」を
//   切り分けるために使う。シートに触らない wake_check（GET）を 1 回だけ叩く。
const TEST_TIMEOUT_MS = 8000;
async function testGasConnection(urlOverride) {
  const data = await chrome.storage.local.get(null);
  const url = String(urlOverride || '').trim() || resolveGasUrl(data);
  if (!url) return { ok: false, error: 'GAS WebアプリURLが未設定です' };
  const started = Date.now();
  const controller = (typeof AbortController !== 'undefined') ? new AbortController() : null;
  let timer = null;
  if (controller) timer = setTimeout(() => { try { controller.abort(); } catch (e) {} }, TEST_TIMEOUT_MS);
  try {
    const sep = (url.indexOf('?') === -1) ? '?' : '&';
    const res = await fetch(url + sep + 'api=wake_check&_t=' + started, {
      method: 'GET', redirect: 'follow', cache: 'no-store',
      signal: controller ? controller.signal : undefined
    });
    const ms = Date.now() - started;
    const text = await res.text();
    let json = null;
    try { json = JSON.parse(text); } catch (e) { json = null; }
    const ok = !!res.ok && !!json && json.success !== false;
    return { ok: ok, status: res.status, ms: ms, json: json, head: text.slice(0, 300), url: url };
  } catch (e) {
    const detail = String((e && e.message) ? e.message : e);
    return { ok: false, ms: Date.now() - started, error: detail, url: url };
  } finally {
    if (timer) clearTimeout(timer);
  }
}

/**
 * GASとのハートビート・ポリシー同期
 */
async function syncWithGas() {
  if (syncInFlight) return; // 前回の同期が未完了ならスキップ（多重実行防止）
  syncInFlight = true;
  try {
    const data = await chrome.storage.local.get(null);
    // 子GAS分散: 割り当て状態をメモリへ写す（以降の判定でストレージを読まない）
    shardSyncMemory(data);
    let studentId = data.student_id;

    // もし student_id が未設定の場合、Googleアカウントの再検出を試みる
    if (!studentId) {
      const email = await getStudentIdentity();
      if (email) {
        studentId = email;
        await chrome.storage.local.set({ student_id: email });
      }
    }

    // 学校名 → GAS URL を解決（1つの拡張機能で13校のGASへ振り分け）。
    // まず保存済みの school_name / gas_url_map から解決する。
    let effectiveGasUrl = resolveGasUrl(data);

    // 子GAS分散（SHARD_MODE）: 割り当て済みなら子GASへ直接送る（resolveGasUrl が最優先で返す）。
    // ただし 6 時間ごとに親へ問い合わせ直し、クラス変更などで割り当てが変わった場合に追従する。
    const assignedFromUrl = String((data && data.assigned_from) || '').trim();
    const assignedAtMs = Number((data && data.assigned_at) || 0);
    let talkingToParent = !shardAssignedUrl(data);
    if (shardAssignedUrl(data) && assignedFromUrl && assignedAtMs &&
        (Date.now() - assignedAtMs) > SHARD_RECHECK_MS) {
      effectiveGasUrl = assignedFromUrl; // 今回は親へ（応答で新しい割り当てが返る）
      talkingToParent = true;
    }

    // 端末の学校名も heartbeat で GAS へ送る。
    // これが無いと GAS 側は端末一覧を「学校名 = 未設定」で登録してしまい、
    // 管理ポリシーで school_name を配布してもシートに反映されない。
    // （教員の学校スコープ判定はシートの学校名を使うため、未設定のままだと全校の教員から見える）
    let schoolNameForGas = String(data.school_name || '').trim();
    if (schoolNameForGas === '未設定') schoolNameForGas = '';

    // 解決できない場合（学校未確定・マップ未取得）は managed storage を再確認する。
    if (!effectiveGasUrl || !data.school_name || data.school_name === '未設定') {
      const managed = await getManagedPolicy();
      const merged = {
        school_name: pickMeaningfulSchoolName(data.school_name, managed.school_name),
        gas_url_map: (data.gas_url_map && Object.keys(data.gas_url_map).length)
          ? data.gas_url_map
          : (managed.gas_url_map || {}),
        gas_url: data.gas_url || managed.gas_url || ''
      };
      const managedGasUrl = resolveGasUrl(merged);
      if (managedGasUrl) effectiveGasUrl = managedGasUrl;

      if (!schoolNameForGas && merged.school_name && merged.school_name !== '未設定') {
        schoolNameForGas = merged.school_name;
      }

      // ポリシー由来の値が保存されていなければ補完保存する
      const persist = {};
      if (merged.gas_url_map && Object.keys(merged.gas_url_map).length &&
          (!data.gas_url_map || !Object.keys(data.gas_url_map).length)) {
        persist.gas_url_map = merged.gas_url_map;
      }
      if (merged.school_name && merged.school_name !== '未設定' &&
          merged.school_name !== data.school_name) {
        persist.school_name = merged.school_name;
      }
      if (merged.gas_url && merged.gas_url !== data.gas_url) {
        persist.gas_url = merged.gas_url;
      }
      if (Object.keys(persist).length) await chrome.storage.local.set(persist);
    }

    if (!effectiveGasUrl || !studentId) {
      // GAS URL または 児童ID が未設定の場合は同期不可
      await recordSyncDiag(false, 'not_configured',
        !effectiveGasUrl ? 'GAS WebアプリURLが未設定です'
                         : '児童ID（Googleアカウント）が未設定です');
      return;
    }

    // 現在のアクティブタブのURLを取得
    const currentUrl = await getActiveTabUrl();

    // GASへPOSTリクエスト
    const payload = {
      action: 'heartbeat',
      student_id: studentId,
      current_url: currentUrl,
      // 端末の学校名（未確定なら空文字）。GAS はこれで端末一覧の学校名を補完する。
      school_name: schoolNameForGas
    };

    // タイムアウト付きで送信する（応答が返らない場合でも syncInFlight を解放し、
    // 以後の同期が永久に止まらないようにする）。
    // 【フェーズ3】送信時刻を控える。応答受信時に往復の中央時刻を求めて
    //   サーバ時刻との差（時計補正）を NTP 風に算出するために使う。
    lastHeartbeatSentMs = Date.now();
    // 【v1.6.6】稼働中の重複トリガー抑止用に「送信開始」時刻も控える。
    lastHeartbeatStartMs = lastHeartbeatSentMs;
    const controller = (typeof AbortController !== 'undefined') ? new AbortController() : null;
    let timer = null;
    if (controller) {
      timer = setTimeout(() => { try { controller.abort(); } catch (e) {} }, SYNC_TIMEOUT_MS);
    }
    let response;
    try {
      response = await fetch(effectiveGasUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'text/plain;charset=utf-8' // GAS Web App のCORS制約対策
        },
        body: JSON.stringify(payload),
        redirect: 'follow',
        signal: controller ? controller.signal : undefined
      });
    } finally {
      if (timer) clearTimeout(timer);
    }

    if (!response.ok) {
      console.warn('[EduAgent] GASレスポンスエラー:', response.status);
      await recordSyncDiag(false, 'http_' + response.status,
        'GASが HTTP ' + response.status + ' を返しました（URLの誤り／デプロイ権限を確認）');
      return;
    }

    let resJson;
    try {
      resJson = await response.json();
    } catch (e) {
      // GAS がログイン画面（HTML）を返した場合などに該当する。
      await recordSyncDiag(false, 'not_json',
        'GASの応答がJSONではありません（Webアプリの「アクセスできるユーザー」を確認）');
      return;
    }
    if (!resJson.success) {
      console.warn('[EduAgent] 同期エラー:', resJson.error);
      await recordSyncDiag(false, 'gas_error',
        'GASがエラーを返しました: ' + String(resJson.error || '(詳細なし)'));
      return;
    }

    // 子GAS分散: 親からの割り当て（assigned_gas_url）を保存し、次回以降の通信先を切り替える。
    // ※ applyPolicies より先に評価するため、data（更新前）と実使用URLを渡す。
    await applyShardAssignment(resJson, data, effectiveGasUrl, talkingToParent);

    // 最新ポリシーの反映
    await applyPolicies(resJson, data);

    // GAS が返す「教員コンソール稼働中か（ka_active）／同期周期（sync_interval_sec）／
    // 非稼働時の再確認猶予（idle_drift_until）」を反映し、同期周期を切り替える。
    //  ・稼働中        : 1.5 秒の速い同期
    //  ・非稼働        : 定期ポーリングを停止（猶予期間のみ低頻度で再確認）
    applyRemoteKeepalive({
      ka_active: resJson.ka_active,
      sync_interval_sec: resJson.sync_interval_sec,
      idle_drift_until: resJson.idle_drift_until
    });

    await recordSyncDiag(true, 'ok', '');

    // 【v1.6.7】成功時刻を控える。復帰通知（handleWakeResume）のクールダウン判定は
    //   「前回の成功から 5 秒」なので、ここでしか更新しない（送信開始では更新しない）。
    lastHeartbeatOkMs = Date.now();
    wakeRetryBudget = 0;   // 成功したら短い再試行の予算は使い切る
    clearWakeRetry();

    // 【v1.6.8】準リアルタイム画面視聴: 送信は既存の 1.5 秒ポーリングに同期させる。
    //   live_watch === true の端末だけが撮影し、in-flight 排他で多重送信しない。
    //   同期の成功処理を済ませた後に実行するため、失敗しても状態更新へ影響しない。
    try {
      if (liveWatchActive === true) await liveWatchCaptureOnce();
    } catch (eLWC) {}

  } catch (err) {
    console.error('[EduAgent] 通信エラー:', err);
    try {
      const detail = String((err && err.message) ? err.message : err);
      await recordSyncDiag(false, 'network',
        'GASへ到達できません（URL・ネットワーク・公開範囲を確認）: ' + detail);
    } catch (e2) {}
    // 【v1.6.7】復帰直後（蓋を開けた／Wi-Fi 再接続中）の失敗は長いバックオフに入れない。
    //   予算（wakeRetryBudget）は復帰通知の瞬間だけ立つ。通常運用の失敗時は 0 なので
    //   従来どおり何もせず、GAS 側の sync_interval_sec（過負荷時 4 秒）に任せる。
    try { scheduleWakeRetry(); } catch (e3) {}
  } finally {
    syncInFlight = false;

    // 【バトンタッチ＝即時ハートビート】v1.6.4 修正
    //   親から新しい assigned_gas_url（子GAS）を受けた回は、この finally で
    //   ガードが下りた「まさにこの一点」でのみ、子GAS宛ての2回目の同期を1回発火する。
    //   ・applyShardAssignment() の中から呼ぶと syncInFlight=true のままなので
    //     先頭のガードに弾かれ、子GASへは一歩も届かない（実機の実行数ゼロの正体）。
    //   ・フラグは消費時に必ず false に戻すため、1割り当てにつき1回限り。
    //     子GASは assigned_gas_url を返さないため、次回以降フラグは立たない。
    //   ・setTimeout(0) で現在のマイクロタスク列を抜けてから再入する
    //     （finally の中で await せず、呼び出し元の完了を待たせない）。
    if (shardHandoffPending) {
      shardHandoffPending = false;
      try {
        setTimeout(function () { syncWithGas(); }, 0);
      } catch (e) {}
    }
  }
}

// ============================================================================
// スケジュール／タイマー  ―  フェーズ3: 端末判定エンジン
//
//   放課後・休日・家庭持ち帰り端末で「指定した時間帯だけ」URL規制/画面ロックを
//   自動で ON にし、時間が来たら自動で解除する。
//
//   【設計の芯】
//     1) 判定は「純粋関数」で行う（Date.now を内部で呼ばない）。
//        時刻は必ず引数 nowMs で渡す → テストで任意の瞬間を再現できる。
//     2) サーバ時刻との差は NTP 風に平滑化して保持する（EMA）。
//        GAS は server_time_ms（数値 epoch）を返すので、通信の往復中央時刻との
//        差分をサンプルとして取り込む。端末の時計が大きく狂っていても
//        予約が「別の日の同じ時刻」に発動する事故を防ぐ。
//     3) スケジュールは「締める方向」にだけ重ねる。
//        学校全体の常時ポリシーを緩めることは絶対にない（安全側）。
//     4) 予約は storage にキャッシュする。オフラインでも、
//        同期が throttle で飛ばされても、境界時刻に正しく発動できる。
//     5) 境界発動は chrome.alarms。MV3 の Service Worker は suspend されるため
//        setTimeout は信用できない（アラームだけが確実に起こす）。
// ============================================================================

const SCHEDULE_OFFSET_SMOOTH = 0.3;        // EMA の平滑化係数
const SCHEDULE_OFFSET_MAX_ABS = 300000;    // 5分超のズレは異常値として捨てる
const SCHEDULE_CACHE_KEY = 'schedule_cache';
const SCHEDULE_EDGE_ALARM = 'scheduleEdge'; // 境界ちょうどに1回だけ起こす
const SCHEDULE_TICK_ALARM = 'scheduleTick'; // 1分ごとの見張り（取りこぼし保険）

let clockOffsetMs = 0;        // サーバ時刻 - 端末時刻（ms）
let scheduleCache = null;     // { schedules:{active,upcoming,overridden_ids}, saved_at }
let lastHeartbeatSentMs = 0;  // 直近ハートビートの送信時刻（RTT 計算用）

/**
 * NTP 風の時計補正（純粋関数）。
 *   往復の中央時刻を基準にサンプルを取り、EMA で滑らかに追従させる。
 *   異常値（5分超）は捨て、既存の補正値を維持する。
 */
function updateClockOffset(serverMs, sentMs, recvMs, curOffset) {
  const cur = (typeof curOffset === 'number' && isFinite(curOffset)) ? curOffset : 0;
  const s = Number(serverMs), a = Number(sentMs), b = Number(recvMs);
  // server_time_ms は「正の epoch ms」。0 / NaN / 未設定はサーバ時刻なしとして無視する
  //   （1970年を本物のサーバ時刻として採用してしまうのを防ぐ）。
  if (!isFinite(s) || s <= 0) return cur;
  // 送受信時刻は 0 でも妥当（!a のような falsy 判定にすると 0 を弾いてしまう）。
  if (!isFinite(a) || !isFinite(b) || a < 0 || b < 0) return cur;
  const mid = (a + b) / 2;
  const sample = s - mid;
  if (Math.abs(sample) > SCHEDULE_OFFSET_MAX_ABS) return cur; // 異常値は捨てる
  if (curOffset === undefined || curOffset === null) return sample; // 初回
  return cur + (sample - cur) * SCHEDULE_OFFSET_SMOOTH;
}

/** 補正後の現在時刻（ms）。offset 省略時は保持中の補正値を使う。 */
function correctedNowMs(offset) {
  const o = (typeof offset === 'number' && isFinite(offset)) ? offset : clockOffsetMs;
  return Date.now() + o;
}

/** 与えられた窓が nowMs を含むか（純粋関数）。 */
function isScheduleActiveAt(s, nowMs) {
  if (!s) return false;
  const start = Number(s.start_ms);
  const end = Number(s.end_ms);
  if (!start || !end || isNaN(start) || isNaN(end)) return false;
  return nowMs >= start && nowMs < end;
}

/** active / upcoming を1本の配列にまとめる（重複IDは除く）。 */
function buildScheduleList(schedules) {
  const out = [];
  const seen = {};
  const push = function (arr) {
    if (!Array.isArray(arr)) return;
    arr.forEach(function (s) {
      if (!s || !s.id) return;
      if (seen[s.id]) return;
      seen[s.id] = true;
      out.push(s);
    });
  };
  if (schedules && typeof schedules === 'object') {
    push(schedules.active);
    push(schedules.upcoming);
  }
  return out;
}

/** ホスト一覧の正規化（小文字・空白除去・空要素の排除）。 */
function normalizeHostList(list) {
  if (!Array.isArray(list)) return [];
  const out = [];
  list.forEach(function (x) {
    const h = String(x === null || x === undefined ? '' : x).trim().toLowerCase();
    if (h && out.indexOf(h) < 0) out.push(h);
  });
  return out;
}

/**
 * 規制モードの重ね合わせ（純粋関数）。
 *   原則: 必ず「締める方向」にだけ倒す。
 *     WHITELIST 同士        … 許可リストの積集合（両方許可したものだけ通す）
 *     WHITELIST と BLACKLIST … WHITELIST を採用し、許可から規制分を差し引く
 *     BLACKLIST 同士        … 規制リストの和集合（規制が増える）
 *     それ以外              … 制限の強い側を採用
 */
function composeFilterRestriction(base, sched) {
  const baseMode = String((base && base.filter_mode) || 'OFF').toUpperCase();
  const baseWhite = normalizeHostList(base && base.whitelist_urls);
  const baseBlack = normalizeHostList(base && base.blacklist_urls);

  if (!sched || String(sched.type || '').toLowerCase() !== 'url_block') {
    return { filter_mode: baseMode, whitelist_urls: baseWhite, blacklist_urls: baseBlack };
  }
  const sMode = String(sched.filter_mode || '').toUpperCase();
  const sWhite = normalizeHostList(sched.whitelist);
  const sBlack = normalizeHostList(sched.blacklist);

  // 1) WHITELIST × WHITELIST → 積集合
  if (baseMode === 'WHITELIST' && sMode === 'WHITELIST') {
    const inter = baseWhite.filter(function (h) { return sWhite.indexOf(h) >= 0; });
    return { filter_mode: 'WHITELIST', whitelist_urls: inter, blacklist_urls: baseBlack };
  }
  // 2) どちらかが WHITELIST → WHITELIST が強い。許可から規制分を差し引く
  if (baseMode === 'WHITELIST' || sMode === 'WHITELIST') {
    const white = (baseMode === 'WHITELIST') ? baseWhite : sWhite;
    const black = (baseMode === 'WHITELIST')
      ? baseBlack.concat(sBlack)
      : sBlack.concat(baseBlack);
    const blackUniq = normalizeHostList(black);
    const whiteTight = white.filter(function (h) { return blackUniq.indexOf(h) < 0; });
    return { filter_mode: 'WHITELIST', whitelist_urls: whiteTight, blacklist_urls: blackUniq };
  }
  // 3) BLACKLIST × BLACKLIST → 和集合
  if (baseMode === 'BLACKLIST' && sMode === 'BLACKLIST') {
    return { filter_mode: 'BLACKLIST', whitelist_urls: baseWhite, blacklist_urls: normalizeHostList(baseBlack.concat(sBlack)) };
  }
  // 4) ベースOFF + スケジュールBLACKLIST
  if (sMode === 'BLACKLIST') {
    return { filter_mode: 'BLACKLIST', whitelist_urls: baseWhite, blacklist_urls: sBlack };
  }
  // 5) それ以外はベース維持
  return { filter_mode: baseMode, whitelist_urls: baseWhite, blacklist_urls: baseBlack };
}

/**
 * いま効いているスケジュール制限を求める（純粋関数）。
 *   解除済み（overridden_ids）は対象外。
 */
function computeEffectiveScheduleRestriction(schedules, nowMs) {
  const result = {
    screen_lock: false,
    url_block: false,
    filter_mode: 'OFF',
    whitelist_urls: [],
    blacklist_urls: [],
    active_ids: []
  };
  const overridden = (schedules && Array.isArray(schedules.overridden_ids))
    ? schedules.overridden_ids : [];
  const list = buildScheduleList(schedules);

  let acc = { filter_mode: 'OFF', whitelist_urls: [], blacklist_urls: [] };
  list.forEach(function (s) {
    if (overridden.indexOf(s.id) >= 0) return;      // 今回だけ解除されている
    if (!isScheduleActiveAt(s, nowMs)) return;      // いまは時間外
    if (result.active_ids.indexOf(s.id) < 0) result.active_ids.push(s.id);
    const type = String(s.type || 'url_block').toLowerCase();
    if (type === 'screen_lock') {
      result.screen_lock = true;
    } else {
      result.url_block = true;
      acc = composeFilterRestriction(acc, s);
    }
  });

  result.filter_mode = acc.filter_mode;
  result.whitelist_urls = acc.whitelist_urls;
  result.blacklist_urls = acc.blacklist_urls;
  return result;
}

/**
 * ベースポリシー（シートの常時設定）とスケジュールを合成する（純粋関数）。
 *   合成結果は必ず「ベース以上に厳しい」。
 */
function composeEffectivePolicy(base, schedules, nowMs) {
  const baseMode = String((base && base.filter_mode) || 'OFF').toUpperCase();
  const baseWhite = normalizeHostList(base && base.whitelist_urls);
  const baseBlack = normalizeHostList(base && base.blacklist_urls);
  const baseLock = !!(base && base.screen_lock);

  const sch = computeEffectiveScheduleRestriction(schedules, nowMs);

  let mode = baseMode, white = baseWhite, black = baseBlack;
  if (sch.url_block) {
    const merged = composeFilterRestriction(
      { filter_mode: baseMode, whitelist_urls: baseWhite, blacklist_urls: baseBlack },
      {
        type: 'url_block',
        filter_mode: sch.filter_mode,
        whitelist: sch.whitelist_urls,
        blacklist: sch.blacklist_urls
      }
    );
    mode = merged.filter_mode;
    white = merged.whitelist_urls;
    black = merged.blacklist_urls;
  }

  return {
    screen_lock: baseLock || sch.screen_lock,
    filter_mode: mode,
    whitelist_urls: white,
    blacklist_urls: black,
    schedule_active_ids: sch.active_ids
  };
}

/** 予約を storage に保存する（オフライン保護の実体）。 */
async function persistScheduleCache(schedules) {
  const safe = (schedules && typeof schedules === 'object')
    ? {
        active: Array.isArray(schedules.active) ? schedules.active : [],
        upcoming: Array.isArray(schedules.upcoming) ? schedules.upcoming : [],
        overridden_ids: Array.isArray(schedules.overridden_ids) ? schedules.overridden_ids : []
      }
    : { active: [], upcoming: [], overridden_ids: [] };
  scheduleCache = { schedules: safe, saved_at: Date.now() };
  try { await chrome.storage.local.set({ [SCHEDULE_CACHE_KEY]: scheduleCache }); } catch (e) {}
  return scheduleCache;
}

/** キャッシュを読む（メモリ → storage）。壊れていても空で返す。 */
async function loadScheduleCache() {
  if (scheduleCache && scheduleCache.schedules) return scheduleCache;
  try {
    const d = await chrome.storage.local.get([SCHEDULE_CACHE_KEY]);
    const c = d && d[SCHEDULE_CACHE_KEY];
    if (c && c.schedules) { scheduleCache = c; return c; }
  } catch (e) {}
  return { schedules: { active: [], upcoming: [], overridden_ids: [] }, saved_at: 0 };
}

/** storage からベースポリシー（合成前のシート値）を読む。 */
async function loadBasePolicy() {
  let d = {};
  try { d = (await chrome.storage.local.get(null)) || {}; } catch (e) { d = {}; }
  return {
    screen_lock: (typeof d.base_screen_lock === 'boolean') ? d.base_screen_lock : !!d.screen_lock,
    filter_mode: d.base_filter_mode || d.filter_mode || 'OFF',
    whitelist_urls: Array.isArray(d.base_whitelist_urls) ? d.base_whitelist_urls
      : (Array.isArray(d.whitelist_urls) ? d.whitelist_urls : []),
    blacklist_urls: Array.isArray(d.base_blacklist_urls) ? d.base_blacklist_urls
      : (Array.isArray(d.blacklist_urls) ? d.blacklist_urls : [])
  };
}

/**
 * 境界アラームを設定する。
 *   次の開始/終了時刻ちょうどに1回起こす scheduleEdge と、
 *   取りこぼし保険の scheduleTick（1分）の二段構え。
 */
async function armScheduleAlarms(schedules, offset) {
  const now = correctedNowMs(offset);
  const overridden = (schedules && Array.isArray(schedules.overridden_ids))
    ? schedules.overridden_ids : [];
  const list = buildScheduleList(schedules);

  let nextEdge = 0;
  list.forEach(function (s) {
    if (overridden.indexOf(s.id) >= 0) return;
    const edges = [Number(s.start_ms), Number(s.end_ms)];
    edges.forEach(function (t) {
      if (!t || isNaN(t)) return;
      if (t > now && (!nextEdge || t < nextEdge)) nextEdge = t;
    });
  });

  try { await chrome.alarms.clear(SCHEDULE_EDGE_ALARM); } catch (e) {}
  if (nextEdge) {
    const delayMs = nextEdge - now + 1000; // 1秒の余裕（時計誤差の吸収）
    if (delayMs >= 1000) {
      try { chrome.alarms.create(SCHEDULE_EDGE_ALARM, { when: Date.now() + delayMs }); } catch (e) {}
    }
  }

  if (list.length) {
    try { chrome.alarms.create(SCHEDULE_TICK_ALARM, { periodInMinutes: 1 }); } catch (e) {}
  } else {
    try { await chrome.alarms.clear(SCHEDULE_TICK_ALARM); } catch (e) {}
  }
}

/**
 * ブラウザ／拡張機能の起動直後に、保存済みの予約から制限状態と境界アラームを復元する。
 *   ※ chrome.alarms は再起動で消えるため、これが無いと「翌朝、予約が効かない」
 *     「終了時刻を過ぎても解除されない」という事故になる。
 *   ※ 予約が1件も無いときは何もしない（無駄なタブ走査・ロック解除を避ける）。
 */
async function restoreSchedulesOnBoot() {
  try {
    const cache = await loadScheduleCache();
    const s = cache.schedules || {};
    const total = (Array.isArray(s.active) ? s.active.length : 0) +
                  (Array.isArray(s.upcoming) ? s.upcoming.length : 0);
    if (total === 0) return;
    await reevaluateSchedules();
    console.log('[EduAgent] スケジュールを復元しました（予約 ' + total + ' 件）');
  } catch (e) {
    console.warn('[EduAgent] スケジュール復元エラー:', e && e.message ? e.message : e);
  }
}

/**
 * 現在時刻でスケジュールを再評価して端末へ適用する。
 *   アラーム（境界・1分）から呼ばれる。通信はしない（キャッシュのみ使用）。
 */
async function reevaluateSchedules() {
  const cache = await loadScheduleCache();
  const base = await loadBasePolicy();
  const eff = composeEffectivePolicy(base, cache.schedules, correctedNowMs(clockOffsetMs));

  const updates = {
    screen_lock: eff.screen_lock,
    filter_mode: eff.filter_mode,
    whitelist_urls: eff.whitelist_urls,
    blacklist_urls: eff.blacklist_urls,
    schedule_active_ids: eff.schedule_active_ids,
    clock_offset_ms: clockOffsetMs
  };
  try { await chrome.storage.local.set(updates); } catch (e) {}

  notifyAllTabsLockState(eff.screen_lock);
  checkAllTabsFiltering(eff.filter_mode, eff.whitelist_urls, eff.blacklist_urls);
  if (eff.screen_lock) {
    checkSpecialTabsForLock();
  } else {
    releaseLockedTabs();
  }

  await armScheduleAlarms(cache.schedules, clockOffsetMs);
  return eff;
}

/**
 * ハートビート応答からスケジュール制限を取り込み、updates を「合成後の値」に差し替える。
 *   ※ applyPolicies の出口で1回だけ呼ぶ最小限の介入点。
 */
async function applyScheduleFromHeartbeat(newPolicy, updates) {
  const policy = newPolicy || {};

  // --- 1) 時計補正 ---
  const serverMs = Number(policy.server_time_ms);
  if (serverMs > 0) {
    const recvMs = Date.now();
    const sentMs = lastHeartbeatSentMs > 0 ? lastHeartbeatSentMs : recvMs;
    clockOffsetMs = updateClockOffset(serverMs, sentMs, recvMs, clockOffsetMs);
  }

  // --- 2) 予約の保存（オフライン保護） ---
  let schedules = { active: [], upcoming: [], overridden_ids: [] };
  if (policy.schedules && typeof policy.schedules === 'object') {
    schedules = policy.schedules;
    await persistScheduleCache(schedules);
  } else {
    const cached = await loadScheduleCache();
    schedules = cached.schedules || schedules;
  }

  // --- 3) ベース（シート値）を保存し、合成結果で上書き ---
  const base = {
    screen_lock: Boolean(policy.screen_lock),
    filter_mode: String(policy.filter_mode || 'OFF').toUpperCase(),
    whitelist_urls: Array.isArray(updates.whitelist_urls) ? updates.whitelist_urls : [],
    blacklist_urls: Array.isArray(updates.blacklist_urls) ? updates.blacklist_urls : []
  };
  updates.base_screen_lock = base.screen_lock;
  updates.base_filter_mode = base.filter_mode;
  updates.base_whitelist_urls = base.whitelist_urls;
  updates.base_blacklist_urls = base.blacklist_urls;
  updates.clock_offset_ms = clockOffsetMs;

  const eff = composeEffectivePolicy(base, schedules, correctedNowMs(clockOffsetMs));
  updates.screen_lock = eff.screen_lock;
  updates.filter_mode = eff.filter_mode;
  updates.whitelist_urls = eff.whitelist_urls;
  updates.blacklist_urls = eff.blacklist_urls;
  updates.schedule_active_ids = eff.schedule_active_ids;

  // --- 4) 境界アラームを張り直す ---
  await armScheduleAlarms(schedules, clockOffsetMs);

  if (eff.schedule_active_ids.length) {
    console.log('[EduAgent] スケジュール制限を適用中:', eff.schedule_active_ids.join(','),
      'mode=' + eff.filter_mode, 'lock=' + eff.screen_lock);
  }
  return eff;
}

/**
 * 取得したポリシーの適用
 */
async function applyPolicies(newPolicy, oldStorage) {
  const updates = {
    last_sync_time: new Date().toLocaleTimeString(),
    // GAS は教員が紐付けるまで「未設定」を返すため、そのまま採用すると
    // 管理ポリシーで配布した学校名が毎回失われる。意味のある値だけを採用する。
    school_name: pickMeaningfulSchoolName(newPolicy.school_name, oldStorage.school_name),
    student_name: newPolicy.student_name || oldStorage.student_name || '',
    class_name: newPolicy.class_name || oldStorage.class_name || '',
    screen_lock: Boolean(newPolicy.screen_lock),
    filter_mode: (newPolicy.filter_mode || 'OFF').toUpperCase(),
    whitelist_urls: Array.isArray(newPolicy.whitelist_urls) ? newPolicy.whitelist_urls : oldStorage.whitelist_urls,
    blacklist_urls: Array.isArray(newPolicy.blacklist_urls) ? newPolicy.blacklist_urls : oldStorage.blacklist_urls
  };

  // 0. 【フェーズ3】スケジュール（タイマー）の合成
  //   ここが唯一の介入点。updates を「シート値」から「シート値＋予約」へ差し替える。
  //   同時に、時計補正の更新・予約キャッシュの保存・境界アラームの再設定を行う。
  //   ※ 合成は「締める方向」のみ。シートの常時ポリシーを緩めることはない。
  try {
    await applyScheduleFromHeartbeat(newPolicy, updates);
  } catch (eSch) {
    // 予約の合成に失敗しても、シート由来のポリシー適用は必ず続行する。
    console.warn('[EduAgent] スケジュール合成をスキップ:', eSch && eSch.message ? eSch.message : eSch);
  }

  // 1. 画面ロック状態の適用
  // ストレージ保存（content.js の chrome.storage.onChanged が全タブで自動発火しリロード不要で即解除）
  await chrome.storage.local.set(updates);

  // 直接メッセージでも念のため全タブに通知
  notifyAllTabsLockState(updates.screen_lock);

  // 2. 一斉表示URL（Broadcast）の検査
  const newBcId = newPolicy.broadcast_id || '';
  const newBcUrl = (newPolicy.broadcast_url || '').trim();

  if (newBcId && newBcId !== oldStorage.last_broadcast_id && newBcUrl) {
    console.log('[EduAgent] 新しい一斉表示URLを検出:', newBcUrl);
    await chrome.storage.local.set({ last_broadcast_id: newBcId });
    openBroadcastUrl(newBcUrl, newBcId);
  }

  // 3. 現在開いているタブのURL規制チェック
  //    規制がOFFに戻った場合でも、ブロック画面のタブを自動復帰させるため常に再検証する
  checkAllTabsFiltering(updates.filter_mode, updates.whitelist_urls, updates.blacklist_urls);

  // 4. 画面ロックの全タブ適用 / 解除時の復帰
  //    すでに開いている通常ページ（スプレッドシート・YouTube・Gmail等のSPA）も、
  //    ページ種別・CSPに依存せず確実にロック画面へ統一表示する（白画面化を防止）。
  const wasLocked = Boolean(oldStorage.screen_lock);
  if (updates.screen_lock) {
    checkSpecialTabsForLock();
  } else if (wasLocked) {
    releaseLockedTabs();
  }

  // 5. 画面一覧（スクリーンショット）要求の検査
  //    教員が「画面情報取得」を押した児童だけに要求日時が入る。
  //    要求ID（日時|reqId）が前回と変わったときだけ撮影・送信する（押下時のみ通信）。
  const newScreenReq = (newPolicy.screen_request_at || '').trim();
  if (newScreenReq && newScreenReq !== (oldStorage.last_screen_request || '')) {
    // 先に記録してから撮影を開始する（多重撮影防止）
    await chrome.storage.local.set({ last_screen_request: newScreenReq });
    captureAndUploadScreenshot();
  }

  // 6. 【v1.6.8】準リアルタイム画面視聴のフラグ反映
  //    ハートビート応答の live_watch が true の端末だけが、以後の 1.5 秒ポーリングで
  //    軽量キャプチャを送る。false（または未指定）になった瞬間に停止する。
  //    ここでは状態の反映のみ行い、撮影は syncWithGas の末尾（1.5秒周期）で行う。
  try {
    await applyLiveWatchFlag(newPolicy.live_watch === true);
  } catch (eLW) {}
}

/**
 * 画面一覧用: 現在のアクティブタブをキャプチャして GAS へアップロードする。
 * ・教員の「画面情報取得」押下（＝screen_request_at の変化）を検知したときだけ実行する。
 * ・通常は見られない chrome://・chrome-extension:// 画面はキャプチャ不可のためスキップする。
 * ・★重要: Google スプレッドシートの 1 セルは 50,000 文字が上限のため、
 *   撮影した JPEG をそのまま送ると保存に失敗して画面が表示されない（＝送信待ちのまま）。
 *   そこで OffscreenCanvas で「Base64 が上限未満に収まるまで」段階的に縮小してから送る。
 */
const SCREENSHOT_MAX_B64 = 42000;                            // 送信する Base64 の上限（セル上限50kに余裕を持たせる）
const SCREENSHOT_WIDTHS = [1024, 800, 640, 480, 360, 280];   // 縮小候補（広い順に試す）
const SCREENSHOT_QUALITIES = [0.7, 0.55, 0.4];               // JPEG 品質候補

// data URL(JPEG) を OffscreenCanvas で縮小し、Base64 が上限未満に収まる最小構成を返す。
async function downscaleForSheet(dataUrl) {
  // まずは原寸の Base64 長を確認（既に十分小さければそのまま使う）
  const originalB64 = String(dataUrl).replace(/^data:image\/[a-z]+;base64,/i, '');
  if (originalB64.length <= SCREENSHOT_MAX_B64) return dataUrl;
  if (typeof createImageBitmap !== 'function' || typeof OffscreenCanvas !== 'function') return null;

  let bitmap;
  try {
    const blob = await (await fetch(dataUrl)).blob();
    bitmap = await createImageBitmap(blob);
  } catch (e) { return null; }

  try {
    for (const w of SCREENSHOT_WIDTHS) {
      if (w > bitmap.width) continue; // 原寸より拡大はしない
      const h = Math.round((bitmap.height * w) / bitmap.width);
      const canvas = new OffscreenCanvas(w, h);
      const ctx = canvas.getContext('2d');
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = 'high';
      ctx.drawImage(bitmap, 0, 0, w, h);
      for (const q of SCREENSHOT_QUALITIES) {
        const blob = await canvas.convertToBlob({ type: 'image/jpeg', quality: q });
        const buf = await blob.arrayBuffer();
        // ArrayBuffer → Base64（SW には btoa がある）
        let bin = '';
        const bytes = new Uint8Array(buf);
        const CH = 0x8000;
        for (let i = 0; i < bytes.length; i += CH) {
          bin += String.fromCharCode.apply(null, bytes.subarray(i, i + CH));
        }
        const b64 = btoa(bin);
        if (b64.length <= SCREENSHOT_MAX_B64) {
          return 'data:image/jpeg;base64,' + b64;
        }
      }
    }
  } catch (e) {
    return null;
  } finally {
    try { bitmap.close(); } catch (e) {}
  }
  return null; // どの組み合わせでも上限に収まらなかった
}

// ============================================================================
// 【v1.6.8】準リアルタイム画面視聴（指定端末のみの軽量キャプチャ送信）
//
//   教員コンソールで「ライブ視聴」を開始した児童端末だけが、ハートビート応答の
//   live_watch === true を受け取る。その端末だけが 1.5 秒ポーリングのたびに
//   アクティブタブを撮影し、教員が見やすい軽量JPEGに縮小して子GASへ送る。
//
//   固定仕様:
//     ・撮影は chrome.tabs.captureVisibleTab（JPEG・低品質）のみ。
//     ・OffscreenCanvas で横幅 480px 前後に縮小し、Base64 30,000 文字以内に収める。
//     ・送信は既存の 1.5 秒ポーリング周期に同期（独立タイマーは増やさない）。
//     ・liveWatchInFlight による排他制御で多重送信しない。
//     ・live_watch === false になった瞬間に停止する（撮影もしない）。
//     ・新規権限は不要（tabs / host_permissions は既存のまま）。
// ============================================================================
const LIVE_WATCH_MAX_B64 = 30000;          // 送信する Base64 の上限（要件: 30,000 文字以内）
const LIVE_WATCH_TARGET_WIDTH = 480;       // 目標の横幅（要件: 480px 前後）
const LIVE_WATCH_MIN_WIDTH = 240;          // 縮小の下限（これ以上は落とさない）
const LIVE_WATCH_QUALITIES = [0.5, 0.42, 0.34, 0.28, 0.22, 0.16];
const LIVE_WATCH_CAPTURE_QUALITY = 40;     // captureVisibleTab の品質（低品質設定）
let liveWatchActive = false;               // ハートビート応答 live_watch の写し
let liveWatchInFlight = false;             // 送信の多重実行ガード（in-flight 排他）
let liveWatchLastSentMs = 0;               // 直近の送信時刻（診断用）

/** ArrayBuffer → Base64（Service Worker には btoa がある）。 */
function bufferToBase64_(buf) {
  let bin = '';
  const bytes = new Uint8Array(buf);
  const CH = 0x8000;
  for (let i = 0; i < bytes.length; i += CH) {
    bin += String.fromCharCode.apply(null, bytes.subarray(i, i + CH));
  }
  return btoa(bin);
}

/**
 * ライブ視聴用の縮小。横幅 480px 前後を起点に、Base64 が上限に収まるまで
 * 幅と品質を段階的に落とす。収まらなければ null（壊れたデータは送らない）。
 */
async function downscaleForLiveWatch(dataUrl) {
  const raw = String(dataUrl || '');
  const originalB64 = raw.replace(/^data:image\/[a-z]+;base64,/i, '');
  if (originalB64.length <= LIVE_WATCH_MAX_B64) return raw;
  if (typeof createImageBitmap !== 'function' || typeof OffscreenCanvas !== 'function') return null;

  let bitmap;
  try {
    const blob = await (await fetch(raw)).blob();
    bitmap = await createImageBitmap(blob);
  } catch (e) {
    return null;
  }

  try {
    let w = Math.min(LIVE_WATCH_TARGET_WIDTH, bitmap.width);
    while (w >= LIVE_WATCH_MIN_WIDTH) {
      const h = Math.max(1, Math.round((bitmap.height * w) / bitmap.width));
      const canvas = new OffscreenCanvas(w, h);
      const ctx = canvas.getContext('2d');
      if (!ctx) return null;
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = 'medium';
      ctx.drawImage(bitmap, 0, 0, w, h);
      for (let qi = 0; qi < LIVE_WATCH_QUALITIES.length; qi++) {
        const blob = await canvas.convertToBlob({ type: 'image/jpeg', quality: LIVE_WATCH_QUALITIES[qi] });
        const b64 = bufferToBase64_(await blob.arrayBuffer());
        if (b64.length <= LIVE_WATCH_MAX_B64) return 'data:image/jpeg;base64,' + b64;
      }
      // 画質を落としきっても収まらないときは幅を縮める
      w = Math.round(w * 0.8);
    }
  } catch (e) {
    return null;
  } finally {
    try { bitmap.close(); } catch (e) {}
  }
  return null;
}

// 【v1.6.8 / R57】Service Worker 環境では OffscreenCanvas / createImageBitmap が
//   使えない（または convertToBlob が失敗する）ことがある。その場合に縮小処理で
//   null を返して「送信ゼロ」になり、管理画面が「端末の送信を待っています…」のまま
//   固まるのを避けるため、撮影品質を段階的に落として再撮影するフォールバックを持つ。
//   それでも上限に収まらないときだけ送信を見送る（壊れたデータは送らない）。
const LIVE_WATCH_FALLBACK_QUALITIES = [40, 28, 18, 10];

/**
 * 軽量フレームを1枚取得する（撮影 → 縮小 → 収まらなければ品質を落として再撮影）。
 *   戻り値: data URL(JPEG) or null
 *   ・1 回目の captureVisibleTab は従来どおり quality 40。
 *   ・OffscreenCanvas が使えるなら 480px へ縮小する。
 *   ・使えない／失敗した場合は、captureVisibleTab の品質だけを下げて再撮影する。
 */
async function captureLightweightLiveFrame_(windowId) {
  let lastRaw = null;
  for (let i = 0; i < LIVE_WATCH_FALLBACK_QUALITIES.length; i++) {
    let raw = null;
    try {
      raw = await chrome.tabs.captureVisibleTab(windowId, {
        format: 'jpeg',
        quality: LIVE_WATCH_FALLBACK_QUALITIES[i]
      });
    } catch (eCap) {
      return null; // 撮影自体ができない（保護ページ等）
    }
    if (!raw || !/^data:image\//.test(raw)) return null;
    lastRaw = raw;

    // ① まず縮小を試す（成功すれば 480px 前後の軽量画像）
    const scaled = await downscaleForLiveWatch(raw);
    if (scaled) return scaled;

    // ② 縮小できなかった場合は、原寸のまま上限に収まっているか確認する
    const b64len = String(raw).replace(/^data:image\/[a-z]+;base64,/i, '').length;
    if (b64len <= LIVE_WATCH_MAX_B64) return raw;

    // ③ どちらも不可 → 次の（より低い）品質で再撮影する
  }
  // 最後の手段: 最高圧縮の撮影結果が上限内なら送る
  if (lastRaw) {
    const b64len = String(lastRaw).replace(/^data:image\/[a-z]+;base64,/i, '').length;
    if (b64len <= LIVE_WATCH_MAX_B64) return lastRaw;
  }
  return null;
}

// ============================================================================
// 【v1.6.9 / R58】画面ロック中・URL規制中の「効いている」ことの可視化
//
//   R57 までは、ロック画面（lock.html）・規制画面（blocked.html）を表示中は
//   自拡張のページ（chrome-extension://）であることを理由にキャプチャを
//   スキップしていた。また chrome:// 等の保護ページでは captureVisibleTab が
//   失敗し、管理画面は「端末の送信を待っています…」のまま放置されていた。
//   そのため教員は「ロック・規制が本当に効いているか」を画面上で確認できなかった。
//
//   R58 では次の 2 点を担保する。
//     ① ロック中・規制中も撮影をスキップしない
//        自拡張のロック画面／規制画面は captureVisibleTab で撮影できるため、
//        そのまま撮って送る（教員がロック画面そのものを目視できる）。
//     ② 撮影できない場合の状態フレーム送信
//        chrome:// 等で captureVisibleTab が失敗しても、ロック／規制が有効なら
//        「🔒 画面ロック中」「🚫 アクセス制限中」＋対象URL＋現在時刻を描いた
//        JPEG を OffscreenCanvas で生成して送る（黒画面のまま放置しない）。
//        ※ ロック中・規制中でない通常の失敗は従来どおり（ダミーは作らない）。
//   新規権限は不要。送信経路（live_frame / screenshot）も従来のまま。
// ============================================================================

// 状態フレームの描画設定（480px 前後のサムネイルでも判別できる大きさで描く）
const RESTRICTION_FRAME_WIDTHS = [640, 512, 400];
const RESTRICTION_FRAME_QUALITIES = [0.55, 0.45, 0.35, 0.26];

// OffscreenCanvas すら使えない環境の最終手段（32x18 の暗色プレースホルダ）。
// 「画像が永久に来ない」よりは「規制中であることが分かる画像」を送る方が有益。
const RESTRICTION_FRAME_STATIC =
  'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDABIMDRANCxIQDhAUExIVGywdGxgYGzYnKSAsQDlEQz85Pj1HUGZXR0thTT0+WXlaYWltcnNyRVV9hnxvhWZwcm7/2wBDARMUFBsXGzQdHTRuST5Jbm5ubm5ubm5ubm5ubm5ubm5ubm5ubm5ubm5ubm5ubm5ubm5ubm5ubm5ubm5ubm5ubm7/wAARCAASACADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwDkKuWtrmBriSNpVBwsa5+Y+uR2qnXQaV/yD4vx/maKsuVG+EpqpOz7GXdWuIBcRxtEpOGjbPyn1ye1U66DVf8AkHy/h/MVz9FKXMgxdNU52XYKKKK1OUKKKKAP/9k=';

/** 状態フレーム用のテキスト切り詰め（はみ出し防止）。 */
function truncateFrameText_(text, max) {
  const s = String(text === undefined || text === null ? '' : text);
  const n = Number(max) || 0;
  if (n <= 0 || s.length <= n) return s;
  return s.slice(0, Math.max(0, n - 1)) + '…';
}

/**
 * 状態フレームに描く内容（見出し・色・対象URL・現在時刻）を組み立てる。
 *   サムネイル（横幅480px前後）でも一目で判別できるよう、短い日本語にする。
 */
function buildRestrictionFrameMeta_(state) {
  const st = state || {};
  const isBlock = st.kind === 'block';
  let timeText = '';
  try {
    const d = new Date();
    const p2 = function (n) { return (n < 10 ? '0' : '') + n; };
    timeText = d.getFullYear() + '/' + p2(d.getMonth() + 1) + '/' + p2(d.getDate()) +
      ' ' + p2(d.getHours()) + ':' + p2(d.getMinutes()) + ':' + p2(d.getSeconds());
  } catch (e) { timeText = ''; }
  const modeText = String(st.mode || '');
  let modeLabel = '';
  if (isBlock) {
    if (modeText === 'WHITELIST') modeLabel = '規制モード: 許可リスト（指定外を制限）';
    else if (modeText === 'BLACKLIST') modeLabel = '規制モード: 禁止リスト（指定先を制限）';
    else modeLabel = modeText ? ('規制モード: ' + modeText) : '規制モード: URL規制中';
  }
  return {
    isBlock: isBlock,
    glyph: isBlock ? '\u{1F6AB}' : '\u{1F512}',              // 🚫 / 🔒
    title: isBlock ? 'アクセス制限中' : '画面ロック中',
    subtitle: isBlock
      ? '先生の指示により、このWebサイトは規制されています'
      : '先生の指示があるまで、端末の操作はできません',
    accent: isBlock ? '#f59e0b' : '#ef4444',
    urlText: truncateFrameText_(st.url || '', 58),
    modeLabel: modeLabel,
    modeText: modeText,
    timeText: timeText
  };
}

/**
 * 指定の横幅で状態フレームを描画し JPEG の data URL を返す。
 *   OffscreenCanvas が使えない／描画に失敗した場合は null（呼び出し側で代替）。
 */
async function drawRestrictionFrame_(meta, width) {
  if (typeof OffscreenCanvas !== 'function') return null;
  const m = meta || {};
  const W = Math.max(240, Math.round(Number(width) || RESTRICTION_FRAME_WIDTHS[0]));
  const H = Math.round(W * 0.5625);   // 16:9
  try {
    const canvas = new OffscreenCanvas(W, H);
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    // 背景（濃紺）＋左のアクセントバー（ロック=赤／規制=橙）
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = m.accent || '#ef4444';
    ctx.fillRect(0, 0, Math.max(8, Math.round(W * 0.022)), H);

    const cx = Math.round(W / 2);
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    // ① アイコン（絵文字。描けない環境では四角にフォールバックするだけ）
    ctx.fillStyle = '#ffffff';
    ctx.font = Math.round(W * 0.15) + 'px sans-serif';
    ctx.fillText(String(m.glyph || ''), cx, Math.round(H * 0.24));

    // ② タイトル（サムネイルでも読める大きさ）
    ctx.font = 'bold ' + Math.round(W * 0.098) + 'px sans-serif';
    ctx.fillText(String(m.title || ''), cx, Math.round(H * 0.46));

    // ③ サブタイトル
    ctx.font = Math.round(W * 0.038) + 'px sans-serif';
    ctx.fillStyle = '#cbd5e1';
    ctx.fillText(truncateFrameText_(m.subtitle || '', 44), cx, Math.round(H * 0.58));

    // ④ 対象URL と 規制モード（左寄せ）
    ctx.textAlign = 'left';
    const padX = Math.round(W * 0.06);
    ctx.font = Math.round(W * 0.032) + 'px monospace';
    ctx.fillStyle = '#94a3b8';
    if (m.isBlock) {
      ctx.fillText('対象URL: ' + (m.urlText || '(不明)'), padX, Math.round(H * 0.71));
      ctx.font = Math.round(W * 0.03) + 'px sans-serif';
      ctx.fillText(truncateFrameText_(m.modeLabel || '', 46), padX, Math.round(H * 0.80));
    } else {
      ctx.fillText('元の画面: ' + (m.urlText || '(不明)'), padX, Math.round(H * 0.71));
      ctx.font = Math.round(W * 0.03) + 'px sans-serif';
      ctx.fillText('ロックは教員の解除操作で自動的に終了します', padX, Math.round(H * 0.80));
    }

    // ⑤ 現在時刻（右下）— 「いつ時点の状態か」を教員が判断できるようにする
    ctx.textAlign = 'right';
    ctx.font = Math.round(W * 0.028) + 'px monospace';
    ctx.fillStyle = '#64748b';
    ctx.fillText(String(m.timeText || ''), Math.round(W * 0.95), Math.round(H * 0.92));

    // ⑥ 上限に収まる品質を探す
    for (let i = 0; i < RESTRICTION_FRAME_QUALITIES.length; i++) {
      const blob = await canvas.convertToBlob({ type: 'image/jpeg', quality: RESTRICTION_FRAME_QUALITIES[i] });
      const b64 = bufferToBase64_(await blob.arrayBuffer());
      if (b64.length <= LIVE_WATCH_MAX_B64) return 'data:image/jpeg;base64,' + b64;
    }
    // ライブ視聴の上限には収まらないが、画像自体は生成できた（呼び出し側が再判定）
    const last = await canvas.convertToBlob({ type: 'image/jpeg', quality: RESTRICTION_FRAME_QUALITIES[0] });
    return 'data:image/jpeg;base64,' + bufferToBase64_(await last.arrayBuffer());
  } catch (e) {
    return null;
  }
}

/**
 * ロック中／規制中を示す 1 枚の JPEG を生成する（撮影できないときの代替）。
 *   maxLen は呼び出し側の上限（ライブ視聴=30,000 / 画面一覧=42,000）。
 *   どの横幅でも上限に収まらなければ、必ず上限内に収まる静的プレースホルダを返す。
 */
async function renderRestrictionStateFrame_(state, maxLen) {
  const limit = Number(maxLen) > 0 ? Number(maxLen) : LIVE_WATCH_MAX_B64;
  const meta = buildRestrictionFrameMeta_(state);
  for (let i = 0; i < RESTRICTION_FRAME_WIDTHS.length; i++) {
    const out = await drawRestrictionFrame_(meta, RESTRICTION_FRAME_WIDTHS[i]);
    if (!out) continue;
    const len = String(out).replace(/^data:image\/[a-z]+;base64,/i, '').length;
    if (len <= limit) return out;
  }
  return RESTRICTION_FRAME_STATIC;   // 956 文字。どの上限にも収まる
}

/**
 * アクティブタブが「画面ロック中／URL規制中」かどうかを判定する。
 *   ・自拡張の lock.html / blocked.html を表示中なら、その画面自体を根拠にする
 *     （URL パラメータに元URL・規制モードが保持されている）。
 *   ・加えてストレージのポリシー（screen_lock / filter_mode）からも判定する
 *     （＝全タブがロック画面へ差し替わる直前の一瞬の隙間も拾う）。
 *   戻り値: { active, kind: 'lock'|'block'|'', url, mode }
 */
function restrictionStateForTab_(data, tabUrl) {
  const url = String(tabUrl || '');
  let selfBase = '';
  try {
    if (chrome && chrome.runtime && typeof chrome.runtime.getURL === 'function') {
      selfBase = chrome.runtime.getURL('');
    }
  } catch (e) { selfBase = ''; }

  // ① 自拡張のロック画面を表示中
  if (selfBase && url.startsWith(selfBase + 'lock.html')) {
    let original = '';
    try { original = new URL(url).searchParams.get('url') || ''; } catch (e) { original = ''; }
    return { active: true, kind: 'lock', url: original, mode: '' };
  }
  // ② 自拡張の規制画面を表示中
  if (selfBase && url.startsWith(selfBase + 'blocked.html')) {
    let original = '', mode = '';
    try {
      const q = new URL(url).searchParams;
      original = q.get('url') || '';
      mode = String(q.get('mode') || '').toUpperCase();
    } catch (e) { original = ''; mode = ''; }
    return { active: true, kind: 'block', url: original, mode: mode };
  }
  // ③ ストレージのポリシー（ロック指示が出ている）
  const d = data || {};
  const locked = (d.screen_lock === true) || (d.screen_locked === true);
  if (locked) return { active: true, kind: 'lock', url: url, mode: '' };
  // ④ ストレージのポリシー（URL規制に該当している）
  const mode = String(d.filter_mode || 'OFF').toUpperCase();
  if (mode && mode !== 'OFF' && url) {
    let blocked = false;
    try {
      blocked = evaluateUrlRestriction(url, mode, d.whitelist_urls || [], d.blacklist_urls || []);
    } catch (e) { blocked = false; }
    if (blocked) return { active: true, kind: 'block', url: url, mode: mode };
  }
  // ⑤ 撮影できないページ（chrome:// 等の特権ページ）で URL 規制が有効な場合
  //    ・evaluateUrlRestriction は chrome:// を素通しする（＝規制対象にしない）ため
  //      「そのページ自身がブロックされた」とは判定できない。
  //    ・しかし規制そのものは有効なので、撮影できない状況では黒画面のまま放置せず
  //      「🚫 規制中」の状態フレームを送る（教員が規制の効力を確認できる）。
  //    ※ 通常の Web ページ（https 等）では従来どおりの判定に任せる（挙動不変）。
  if (mode && mode !== 'OFF') {
    const uncapturable = !url ||
      url.startsWith('chrome://') || url.startsWith('chrome-extension://') ||
      url.startsWith('about:') || url.startsWith('devtools://') ||
      url.startsWith('chrome-search://') || url.startsWith('view-source:');
    if (uncapturable) {
      return { active: true, kind: 'block', url: url, mode: mode, restricted_page: true };
    }
  }
  return { active: false, kind: '', url: url, mode: '' };
}

/**
 * live_watch フラグの反映（毎ハートビートで呼ばれる）。
 *   true  … 以後のポーリングで撮影・送信を開始する
 *   false … 即座に停止する（以降の撮影もしない）
 */
async function applyLiveWatchFlag(flag) {
  const next = flag === true;
  if (liveWatchActive === next) return liveWatchActive;
  liveWatchActive = next;
  if (!next) {
    // 停止指示が来た瞬間にフラグを落とす。実行中の送信は完了させ、
    // 以後の新しい撮影は liveWatchActive を見て開始しない（即時停止）。
    liveWatchLastSentMs = 0;
  }
  try {
    await chrome.storage.local.set({ live_watch_active: next });
  } catch (e) {}
  console.log('[EduAgent] ライブ視聴:', next ? '開始（指定端末として撮影を送信します）' : '停止（撮影を止めました）');
  return liveWatchActive;
}

/**
 * ライブ視聴の1回分の撮影・送信。
 *  ・live_watch === true の端末だけが実行する（呼び出し側も確認している）。
 *  ・1.5 秒ポーリングのたびに 1 回だけ走らせ、in-flight 中は必ず捨てる。
 *  ・失敗はログのみ（他の同期処理へ影響させない＝画面ロック等を止めない）。
 */
async function liveWatchCaptureOnce() {
  if (!liveWatchActive) return false;   // 停止指示後は一切撮影しない（即時停止）
  if (liveWatchInFlight) return false;  // 多重送信しない
  liveWatchInFlight = true;
  try {
    const data = await chrome.storage.local.get(null);
    if (!liveWatchActive) return false; // 読み込み中に停止された場合も撮らない
    const studentId = data.student_id;
    const gasUrl = resolveGasUrl(data);
    if (!studentId || !gasUrl) return false;

    let tab = null;
    try {
      const tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      tab = tabs && tabs[0] ? tabs[0] : null;
    } catch (e) {}
    if (!tab) return false;
    if (!tab.windowId) return false;

    const url = tab.url || '';

    // 【R58】ロック中・規制中かを先に判定する。
    //   撮影に失敗したとき「状態フレーム」を描くかどうかの判断に使う。
    let rest = { active: false, kind: '', url: url, mode: '' };
    try {
      rest = restrictionStateForTab_(data, url);
    } catch (eRest) {
      rest = { active: false, kind: '', url: url, mode: '' };
    }

    // 【R58】自拡張のロック画面（lock.html）・規制画面（blocked.html）は
    //   chrome-extension:// ではあるが captureVisibleTab で撮影できるため、
    //   「ロック・規制が効いていること」を教員に見せる最重要画面として撮影対象にする。
    let selfBase = '';
    try { selfBase = chrome.runtime.getURL(''); } catch (eSelf) { selfBase = ''; }
    const isOwnPage = !!selfBase && url.startsWith(selfBase);
    // Chrome の仕様で撮影できない特権ページ（自拡張ページは除く）
    const protectedPage = !isOwnPage && (
      url.startsWith('chrome://') || url.startsWith('chrome-extension://') ||
      url.startsWith('about:') || url.startsWith('devtools://') ||
      url.startsWith('chrome-search://') || url.startsWith('view-source:'));

    let dataUrl = null;
    if (!protectedPage) {
      let raw = null;
      try {
        raw = await chrome.tabs.captureVisibleTab(tab.windowId, {
          format: 'jpeg',
          quality: LIVE_WATCH_CAPTURE_QUALITY
        });
      } catch (eCap) {
        raw = null;
      }
      if (raw && /^data:image\//.test(raw)) {
        // 【R57】縮小（OffscreenCanvas）が使えない Service Worker でも送信が
        //   握りつぶされないよう、失敗時は撮影品質を段階的に落として再撮影する。
        //   1 枚目が既に上限内ならそのまま使う（無駄な再撮影をしない）。
        const rawLen = String(raw).replace(/^data:image\/[a-z]+;base64,/i, '').length;
        dataUrl = rawLen > LIVE_WATCH_MAX_B64
          ? await captureLightweightLiveFrame_(tab.windowId)
          : raw;
      }
    }

    // 【R58】撮れなかった場合でも、ロック中・規制中なら「その状態」を描いた
    //   フレームを送る（管理画面を『端末の送信を待っています…』のまま放置しない）。
    //   ※ ロック中・規制中でない通常時の失敗は、従来どおり送らない（ダミーを作らない）。
    if (!dataUrl) {
      if (!rest.active) return false;
      dataUrl = await renderRestrictionStateFrame_(rest, LIVE_WATCH_MAX_B64);
    }
    if (!dataUrl) return false;
    if (!liveWatchActive) return false; // 縮小中に停止されたら送らない

    let response = null;
    try {
      response = await fetch(gasUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
        body: JSON.stringify({
          action: 'live_frame',
          student_id: studentId,
          image_data: dataUrl,
          mime_type: 'image/jpeg'
        }),
        redirect: 'follow'
      });
    } catch (eNet) {
      return false;
    }
    liveWatchLastSentMs = Date.now();
    if (!response || !response.ok) return false;

    let body = null;
    try { body = await response.json(); } catch (eJson) { body = null; }
    // 枠が解放されていた（TTL 切れ・停止・上限）場合は、次のハートビートで
    // live_watch=false が届くまでの間、無駄な撮影を続けないよう記録だけ残す。
    if (body && body.accepted === false) return false;
    return true;
  } catch (err) {
    return false;
  } finally {
    liveWatchInFlight = false;
  }
}

/**
 * 【R43.3】「撮影できなかった」ことを子GASへ通知する（画像を含まない軽量POST）。
 *
 * 背景（実機の DevTools で確定した真因）:
 *   ログイン状態のトップ画面（新しいタブ）は Chrome の仕様上 chrome://newtab/
 *   という特権ページになり、chrome.tabs.captureVisibleTab では撮影できない。
 *   ログアウト時は https://www.google.com になるため撮影できていた
 *   （＝ログイン/ログアウトで症状が分かれた理由はこれで完全に説明できる）。
 *
 *   R43.2 までは「撮れない」とログを出して return するだけで、GAS へは何も
 *   届かなかった。そのため教員画面は「更新待ち」のまま永久に待ち続けていた。
 *   撮れないこと自体は Chrome の仕様なので、画像の代わりに「撮れなかった」という
 *   事実（理由コード）だけを送り、教員画面が理由を表示できるようにする。
 *
 * 画面一覧は補助機能のため、この通知の失敗は他の同期処理へ影響させない。
 */
async function notifyScreenshotBlocked(gasUrl, studentId, reason) {
  const kind = reason || 'chrome_protected';
  try {
    if (!gasUrl || !studentId) return;
    const response = await fetch(gasUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify({
        action: 'screenshot_blocked',
        student_id: studentId,
        reason: kind
      }),
      redirect: 'follow'
    });
    if (!response || !response.ok) {
      console.warn('[EduAgent] キャプチャ不可の通知が拒否されました: HTTP ' +
        (response ? response.status : 0) + ' (' + kind + ')');
      return;
    }
    console.log('[EduAgent] キャプチャ不可を通知しました:', kind);
  } catch (e) {
    console.warn('[EduAgent] キャプチャ不可の通知に失敗（通信）:',
      e && e.message ? e.message : e, '(' + kind + ')');
  }
}

/**
 * 【R58】画面情報（スクリーンショット）を子GASへ送る共通処理。
 *   通常の撮影結果と「ロック中・規制中の状態フレーム」の両方から使う。
 *   送信結果の検証（HTTP ステータス・success フラグ）は従来と同じ扱い。
 */
async function postScreenshotPayload_(gasUrl, studentId, dataUrl) {
  let response = null;
  try {
    response = await fetch(gasUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify({
        action: 'screenshot',
        student_id: studentId,
        image_data: dataUrl,
        mime_type: 'image/jpeg'
      }),
      redirect: 'follow'
    });
  } catch (eNet) {
    console.warn('[EduAgent] 画面情報の送信に失敗（通信）:',
      eNet && eNet.message ? eNet.message : eNet, '(base64 ' + String(dataUrl).length + ' 文字)');
    return false;
  }
  if (!response || !response.ok) {
    console.warn('[EduAgent] 画面情報の送信が拒否されました: HTTP ' +
      (response ? response.status : 0) + '（base64 ' + String(dataUrl).length + ' 文字）');
    return false;
  }
  let body = null;
  try { body = await response.json(); } catch (eJson) { body = null; }
  if (body && body.success === false) {
    console.warn('[EduAgent] 画面情報の保存に失敗:',
      body.error_code || '', body.error || '', '(base64 ' + String(dataUrl).length + ' 文字)');
    return false;
  }
  console.log('[EduAgent] 画面情報（スクリーンショット）を送信しました', String(dataUrl).length);
  return true;
}

async function captureAndUploadScreenshot() {
  try {
    const data = await chrome.storage.local.get(null);
    const studentId = data.student_id;
    const effectiveGasUrl = resolveGasUrl(data);
    if (!studentId || !effectiveGasUrl) return;

    // アクティブタブ（最後に操作したウィンドウ）を取得
    let tab = null;
    try {
      const tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      tab = tabs && tabs[0] ? tabs[0] : null;
    } catch (e) {}
    if (!tab) {
      try {
        const all = await chrome.tabs.query({ active: true });
        tab = all && all[0] ? all[0] : null;
      } catch (e) {}
    }
    if (!tab || !tab.windowId) return;

    // 【R58】ロック中・規制中かを先に判定する（撮影失敗時の状態フレーム生成に使う）。
    const url = tab.url || '';
    let rest = { active: false, kind: '', url: url, mode: '' };
    try {
      rest = restrictionStateForTab_(data, url);
    } catch (eRest) {
      rest = { active: false, kind: '', url: url, mode: '' };
    }

    // 【R43.2】キャプチャ不可のページ（内部ページ・拡張機能ページ）は
    //   黙って return せず、理由を必ずログに残す（原因究明のため）。
    //   画面一覧は補助機能のため、通知できなくても他の同期処理には影響させない。
    // 【R43.3】さらに「撮れなかった」ことを子GASへ通知する。
    //   chrome://newtab/（ログイン状態の新しいタブ）は Chrome の仕様上
    //   captureVisibleTab で撮影できず、待っても永久に画像は来ない。
    //   通知しないと教員画面の「更新待ち」が解除されないまま残る。
    // 【R58】ただしロック中・規制中のときは「撮れなかった」で終わらせず、
    //   その状態を描いた画像を送る（教員が規制の効力を画面で確認できるようにする）。
    let selfBase = '';
    try { selfBase = chrome.runtime.getURL(''); } catch (eSelf) { selfBase = ''; }
    const isOwnPage = !!selfBase && url.startsWith(selfBase);
    const protectedPage = !isOwnPage && (
      url.startsWith('chrome://') || url.startsWith('chrome-extension://') ||
      url.startsWith('about:') || url.startsWith('devtools://'));

    let raw = null;
    if (!protectedPage) {
      // 【R43.2】captureVisibleTab の失敗を握り潰さない。
      //   URL 判定をすり抜ける保護ページや非アクティブウィンドウでも例外になる。
      try {
        raw = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'jpeg', quality: 70 });
      } catch (eCap) {
        console.warn('[EduAgent] 画面キャプチャに失敗（送信しません）:',
          eCap && eCap.message ? eCap.message : eCap);
        raw = null;
      }
      if (raw && !/^data:image\//.test(raw)) raw = null;
    }

    // 【R58】撮れなかった（保護ページ／撮影例外）ときの分岐。
    //   ・ロック中・規制中 → 状態フレームを生成して送る（黒画面のまま放置しない）
    //   ・通常時          → 従来どおり「撮れなかった」を通知して終了
    if (!raw) {
      if (!rest.active) {
        const reason = protectedPage ? 'chrome_protected' : 'capture_error';
        console.warn('[EduAgent] 画面キャプチャ不可（保護されたページ）のため送信しません:', url);
        await notifyScreenshotBlocked(effectiveGasUrl, studentId, reason);
        return;
      }
      const stateFrame = await renderRestrictionStateFrame_(rest, SCREENSHOT_MAX_B64);
      if (!stateFrame) {
        await notifyScreenshotBlocked(effectiveGasUrl, studentId, 'capture_error');
        return;
      }
      console.log('[EduAgent] ロック中・規制中のため状態フレームを送信します:', rest.kind);
      await postScreenshotPayload_(effectiveGasUrl, studentId, stateFrame);
      return;
    }

    // セル上限に収まるよう縮小（収まらなければ送信しない＝壊れたデータを残さない）
    // 【R43.3】縮小しきれなかった場合も通知する（理由: image_too_large）。
    //   通知しないと「端末の送信待ち」のまま残り、教員が原因を知れない。
    const dataUrl = await downscaleForSheet(raw);
    if (!dataUrl) {
      // 【R58】ロック中・規制中なら、縮小できなくても状態フレームで代替する。
      if (rest.active) {
        const stateFrame = await renderRestrictionStateFrame_(rest, SCREENSHOT_MAX_B64);
        if (stateFrame) {
          await postScreenshotPayload_(effectiveGasUrl, studentId, stateFrame);
          return;
        }
      }
      console.warn('[EduAgent] 画面情報を上限サイズまで縮小できませんでした');
      await notifyScreenshotBlocked(effectiveGasUrl, studentId, 'image_too_large');
      return;
    }

    // 【R43.2】レスポンスを検証する。
    //   R43.1 までは response.ok を見ておらず、GAS が 500 を返しても
    //   「送信しました」と出力していた（実機で原因究明を遅らせた誤ログ）。
    // 【R58】送信処理は postScreenshotPayload_ へ集約した（状態フレームと共通）。
    await postScreenshotPayload_(effectiveGasUrl, studentId, dataUrl);
  } catch (err) {
    // captureVisibleTab はマニフェスト権限が無い/対象外ページで失敗する。
    // 画面一覧は補助機能のため、失敗しても他の同期処理には影響させない。
    console.warn('[EduAgent] 画面キャプチャをスキップ:', err && err.message ? err.message : err);
  }
}

/**
 * 全タブに対して画面ロック状態を通知
 * ※ ロック画面/規制画面（chrome-extension://）にも通知し、
 *    ロック解除時にリロードなしで即座に元画面へ復帰させる。
 */
async function notifyAllTabsLockState(locked) {
  try {
    const tabs = await chrome.tabs.query({});
    for (const tab of tabs) {
      if (!tab.id) continue;
      chrome.tabs.sendMessage(tab.id, {
        type: 'SET_LOCK_STATE',
        locked: locked
      }).catch(() => {});
    }
  } catch (err) {
    console.error('[EduAgent] タブへの通知エラー:', err);
  }
}

/**
 * 画面ロック中、すべてのタブを専用ロック画面（lock.html）へ統一表示する。
 * ・SPA（スプレッドシート・YouTube・Gmail等）はDOM上書きでは内容が透けて白画面化するため、
 *   ページ自体をロック画面へ差し替える（＝重いページをアンロードする）。
 * ・元のURLは lock.html の url パラメータに保持し、解除時に background 側で自動復帰させる。
 * ・Webサイト側のCSP・リソース状況に依存せず、全ページ種別で同一デザインを保証する。
 */
async function checkSpecialTabsForLock() {
  try {
    const tabs = await chrome.tabs.query({});
    for (const tab of tabs) {
      if (!tab.id) continue;
      // 一斉配信直後のタブはロック画面へ差し替えない（新規タブで表示させるため）
      if (isBroadcastGuardedTab(tab.id)) continue;
      const url = tab.url || '';
      if (isLockableUrl(url)) {
        redirectTabToLock(tab.id, url);
      }
    }
  } catch (e) {}
}

/**
 * ロック画面へ差し替えるべきタブのURLかどうかを判定する。
 * ・自分自身の拡張機能ページ（lock.html / blocked.html / popup等）は対象外
 * ・chrome:// 系の内部ページは chrome.tabs.update で遷移できないため対象外
 * ・新規タブ・空白ページ・通常のWebページ（http/https）は対象
 */
function isLockableUrl(url) {
  if (!url) return true; // URL未確定の新規タブはロック画面へ
  const self = chrome.runtime.getURL('');
  if (url.startsWith(self)) return false;              // 拡張機能自身のページ
  if (url.startsWith('chrome-extension://')) return false;
  if (url.startsWith('chrome://') && !url.startsWith('chrome://newtab')) return false;
  if (url.startsWith('about:') && url !== 'about:blank') return false;
  return true;
}

/**
 * タブをロック画面へ転送（元URLをクエリに保持して解除時に復帰できるようにする）
 */
function redirectTabToLock(tabId, originalUrl) {
  const lockUrl = chrome.runtime.getURL('lock.html') +
    `?url=${encodeURIComponent(originalUrl || '')}`;
  chrome.tabs.update(tabId, { url: lockUrl });
}

/**
 * 画面ロック解除時：ロック画面へ差し替えたタブを元のURLへ自動復帰させる
 */
async function releaseLockedTabs() {
  // ロック解除時の復帰は、まずロック画面自身(lock.js)が即座に実行する。
  // （ロック画面のストレージ変更リスナーが最速で window.location.replace する）
  // ここは「lock.js が何らかの理由で復帰できなかった場合」の保険として機能させる。
  // ・両者が同時に遷移すると二重遷移となり、画面が一瞬ちらつく（消えたり出たりする）ため、
  //   少し待ってから『まだロック画面のままのタブ』に限って復帰させる。
  // ・これにより、lock.js が先に復帰したタブには一切手を出さず、競合を避けられる。
  await new Promise((resolve) => setTimeout(resolve, 700));
  try {
    const tabs = await chrome.tabs.query({});
    const lockBase = chrome.runtime.getURL('lock.html');
    for (const tab of tabs) {
      if (!tab.id || !tab.url || !tab.url.startsWith(lockBase)) continue;
      let originalUrl = '';
      try {
        originalUrl = new URL(tab.url).searchParams.get('url') || '';
      } catch (e) {}
      if (originalUrl && /^https?:\/\//i.test(originalUrl)) {
        chrome.tabs.update(tab.id, { url: originalUrl });
      } else {
        // 元URLが保持されていない場合は新規タブ画面へ戻す
        chrome.tabs.update(tab.id, { url: 'chrome://newtab' });
      }
    }
  } catch (e) {}
}

// 一斉配信直後のタブを、ロック処理（閉じる/ロック画面差し替え/URL規制）から保護する期限。
// （配信はロック中でも確実に新規タブで表示される必要があるため）
let broadcastGuardUntil = 0;
let broadcastTabId = null;
// 同一配信IDの二重オープン防止
let lastBroadcastOpenedId = '';
// 【要件2】同一URLの二重オープン防止（時間窓）。
//   GAS側で broadcast_id を統一しても、経路（親/子直送/保留キューflush）の
//   重複やID再発番が起きると同じページが2枚開く。ここは最後の安全網として
//   「直近30秒以内に同じURLを自動オープン済みなら、IDが違っても開かない」を担う。
const BROADCAST_DEDUP_WINDOW_MS = 30000;
let lastBroadcastUrls = [];   // [{ url: string, at: number }]

// URLの比較用正規化（末尾スラッシュ・大文字小文字・既定ポート差を吸収）
function normalizeBroadcastUrl(u) {
  let v = String(u || '').trim();
  if (!v) return '';
  if (!/^https?:\/\//i.test(v)) v = 'https://' + v;
  try {
    const parsed = new URL(v);
    let host = parsed.hostname.toLowerCase();
    let port = parsed.port;
    if ((parsed.protocol === 'https:' && port === '443') ||
        (parsed.protocol === 'http:' && port === '80')) port = '';
    let path = parsed.pathname || '/';
    if (path.length > 1 && path.charAt(path.length - 1) === '/') path = path.slice(0, -1);
    return parsed.protocol.toLowerCase() + '//' + host + (port ? ':' + port : '') +
      path + (parsed.search || '');
  } catch (e) {
    return v.replace(/\/+$/, '').toLowerCase();
  }
}

// 直近に同じURLを自動オープンしたか（時間窓内）。判定と記録を同時に行う。
//   true  = 開いてよい（記録した）
//   false = 窓内で同一URLを既に開いている（抑止）
//   空URL（配信の解除）は対象外＝常に true。
function claimBroadcastUrlOnce(url, nowMs) {
  const now = (typeof nowMs === 'number') ? nowMs : Date.now();
  const key = normalizeBroadcastUrl(url);
  if (!key) return true;
  const win = (typeof BROADCAST_DEDUP_WINDOW_MS === 'number' && BROADCAST_DEDUP_WINDOW_MS > 0)
    ? BROADCAST_DEDUP_WINDOW_MS : 30000;
  lastBroadcastUrls = (Array.isArray(lastBroadcastUrls) ? lastBroadcastUrls : []).filter(function (e) {
    return e && typeof e.at === 'number' && (now - e.at) < win;
  });
  for (let i = 0; i < lastBroadcastUrls.length; i++) {
    if (lastBroadcastUrls[i].url === key) return false;   // 窓内で同一URL → 抑止
  }
  lastBroadcastUrls.push({ url: key, at: now });
  return true;
}

/**
 * 一斉配信直後に保護すべきタブかどうかを判定する。
 */
function isBroadcastGuardedTab(tabId) {
  if (Date.now() >= broadcastGuardUntil) return false;
  if (broadcastTabId != null && tabId === broadcastTabId) return true;
  return false;
}

/**
 * 一斉表示URLを新しいタブで開く
 * ※ 教員の「一斉URL配信」は、児童の現在の作業を中断させないよう
 *    必ず新しいタブで開く（既存タブを上書きしない）。
 * ※ 画面ロック中であっても配信URLは新規タブで表示する。
 *    直後に走るロック処理（タブ閉じ/ロック画面差し替え/URL規制）から配信タブを保護する。
 */
async function openBroadcastUrl(url, broadcastId) {
  try {
    if (broadcastId && broadcastId === lastBroadcastOpenedId) {
      return; // 同一配信の二重オープン防止
    }
    let validUrl = url;
    if (!validUrl.startsWith('http://') && !validUrl.startsWith('https://')) {
      validUrl = 'https://' + validUrl;
    }
    // 【要件2】IDが違っても、直近30秒以内に同じURLを開いていれば開かない。
    //   これが無いと、経路の重複やID再発番で同じページが2枚開く（実機症状）。
    //   空URL（配信の解除）は対象外。
    //   抑止した場合も「処理済みID」だけは記録し、以降の再送も弾けるようにする。
    if (!claimBroadcastUrlOnce(validUrl)) {
      if (broadcastId) lastBroadcastOpenedId = broadcastId;
      console.log('[EduAgent] 同一URLの二重オープンを抑止:', validUrl);
      return;
    }
    if (broadcastId) lastBroadcastOpenedId = broadcastId;

    // 直後のロック/規制処理から保護する期間を設定
    broadcastGuardUntil = Date.now() + 6000;
    broadcastTabId = null;

    const created = await chrome.tabs.create({ url: validUrl, active: true });
    if (created && created.id) broadcastTabId = created.id;

    // 保護期限後に参照が残らないようクリア
    setTimeout(() => { broadcastTabId = null; }, 7000);
  } catch (err) {
    console.error('[EduAgent] 一斉URL表示エラー:', err);
  }
}

/**
 * 現在のアクティブタブのURL取得
 */
async function getActiveTabUrl() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    return tab && tab.url ? tab.url : '';
  } catch (e) {
    return '';
  }
}

/**
 * タブ作成イベントの監視（ロック中の新規タブをロック画面へ誘導）
 */
chrome.tabs.onCreated.addListener(async (tab) => {
  if (!tab.id) return;
  // 停止中に管理アプリ（教員コンソール）が再度開かれたら通常同期へ復帰する。
  resumeFromConsoleTab(tab.url || (tab.pendingUrl || ''));
  // 一斉配信直後はロック中でも配信タブを閉じない/差し替えない（新規タブで表示するため）
  if (Date.now() < broadcastGuardUntil) return;
  const data = await chrome.storage.local.get(['screen_lock']);
  if (!data.screen_lock) return;
  const url = tab.url || '';
  // 拡張機能自身のページ（lock.html等）は対象外。
  if (url.startsWith(chrome.runtime.getURL(''))) return;

  // ロック中は新しいタブを増やさない：
  //  ・アクティブなロック画面(lock.html)を持つタブが既にあれば、開かれた新規タブは即座に閉じる
  //  ・無ければ（＝全タブがロック画面でない特殊状況）新規タブをロック画面へ誘導する
  try {
    const lockBase = chrome.runtime.getURL('lock.html');
    const tabs = await chrome.tabs.query({});
    const existingLockTab = tabs.find(t => t.id !== tab.id && (t.url || '').startsWith(lockBase));
    if (existingLockTab && existingLockTab.id) {
      // 既にロック画面が開いているので、新しいタブは開かせない（増やさない）
      chrome.tabs.remove(tab.id).catch(() => {});
      if (existingLockTab.windowId != null) {
        chrome.windows.update(existingLockTab.windowId, { focused: true }).catch(() => {});
      }
      chrome.tabs.update(existingLockTab.id, { active: true }).catch(() => {});
      return;
    }
  } catch (e) {}

  redirectTabToLock(tab.id, /^https?:\/\//i.test(url) ? url : '');
});

/**
 * タブ更新イベントの監視（URLフィルタリング & ロック適用）
 */
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.url || changeInfo.status === 'loading') {
    const url = changeInfo.url || tab.url;
    if (!url) return;

    // 停止中に管理アプリ（教員コンソール）が開かれた/遷移したら通常同期へ復帰する。
    resumeFromConsoleTab(url);

    // 一斉配信直後のタブはロック/規制の対象外（新規タブで配信URLを表示させるため）
    if (isBroadcastGuardedTab(tabId)) return;

    const data = await chrome.storage.local.get(['filter_mode', 'whitelist_urls', 'blacklist_urls', 'screen_lock']);

    // ロック中は、通常のWebページ・新規タブ・空白ページを一律ロック画面へ差し替える。
    // すでにロック画面/規制画面/拡張機能ページのタブは対象外（無限リダイレクト防止）。
    if (data.screen_lock && isLockableUrl(url)) {
      redirectTabToLock(tabId, /^https?:\/\//i.test(url) ? url : '');
      return;
    }

    // URL規制判定
    if (data.filter_mode && data.filter_mode !== 'OFF') {
      const isBlocked = evaluateUrlRestriction(url, data.filter_mode, data.whitelist_urls || [], data.blacklist_urls || []);
      if (isBlocked) {
        redirectToBlockedPage(tabId, url, data.filter_mode);
        return;
      }
    }
  }
});

/**
 * ウィンドウのフォーカス変化を監視（停止後も教員が端末を操作したら即復帰）。
 * 児童が「ロック画面のみ」を表示している等で他タブが無い場合、教員がコンソールを開いても
 * タブ作成/更新イベントが拾えないことがある。ウィンドウのフォーカス変化（＝人が端末を操作した）
 * で SW が起きるため、ここでアクティブタブを確認して復帰判定する。
 * ※ 稼働中は resumeFromConsoleTab が即 return するため負荷はない。停止中の起床も操作時のみ。
 * 【v1.6.7】ウィンドウ復帰（別ウィンドウから戻った／蓋を開けた）の瞬間にも即時ハートビートを
 *   打つ。ただし handleWakeResume 側のクールダウン（成功から 5 秒）で、通常のウィンドウ切替では
 *   追加の通信が起きない（稼働中は 1.5 秒ごとに成功しているため常にクールダウン内）。
 */
if (chrome.windows && chrome.windows.onFocusChanged) {
  chrome.windows.onFocusChanged.addListener(async (winId) => {
    // フォーカスが「どのウィンドウにも無い」（デスクトップ・スリープ移行）は復帰ではない。
    const NONE = (chrome.windows && chrome.windows.WINDOW_ID_NONE !== undefined)
      ? chrome.windows.WINDOW_ID_NONE : -1;
    if (winId !== undefined && winId === NONE) return;
    try { handleWakeResume('focus'); } catch (e) {}
    try {
      const tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      const tab = tabs && tabs[0];
      if (tab && tab.url) resumeFromConsoleTab(tab.url);
    } catch (e) {}
  });
}

/**
 * 全タブのURL規制を再検証
 *  - 規制対象のURLを開いているタブはブロック画面へリダイレクト
 *  - すでにブロック画面を表示しているタブは、規制が解除されていれば元のURLへ自動復帰
 */
async function checkAllTabsFiltering(mode, whitelist, blacklist) {
  try {
    const tabs = await chrome.tabs.query({});
    const blockPageBase = chrome.runtime.getURL('blocked.html');
    const effectiveMode = (mode || 'OFF').toUpperCase();

    for (const tab of tabs) {
      if (!tab.id || !tab.url) continue;
      // 一斉配信直後のタブはURL規制の対象外（新規タブで配信URLを表示させるため）
      if (isBroadcastGuardedTab(tab.id)) continue;

      // A. すでにブロック画面を表示中のタブ → 規制解除済みなら元URLへ復帰
      if (tab.url.startsWith(blockPageBase)) {
        try {
          const q = new URL(tab.url).searchParams;
          const originalUrl = q.get('url') || '';
          if (originalUrl) {
            const stillBlocked = evaluateUrlRestriction(originalUrl, effectiveMode, whitelist || [], blacklist || []);
            if (!stillBlocked) {
              console.log('[EduAgent] URL規制が解除されたため元の画面へ復帰:', originalUrl);
              chrome.tabs.update(tab.id, { url: originalUrl });
            }
          }
        } catch (e) {}
        continue;
      }

      // B. 通常のタブ → 規制対象ならブロック画面へ
      if (effectiveMode !== 'OFF') {
        const isBlocked = evaluateUrlRestriction(tab.url, effectiveMode, whitelist, blacklist);
        if (isBlocked) {
          redirectToBlockedPage(tab.id, tab.url, effectiveMode);
        }
      }
    }
  } catch (err) {
    console.error('[EduAgent] URL規制チェックエラー:', err);
  }
}

/**
 * URLが規制対象かどうかの判定
 */
function evaluateUrlRestriction(rawUrl, mode, whitelist, blacklist) {
  if (rawUrl.startsWith('chrome://') || 
      rawUrl.startsWith('chrome-extension://') || 
      rawUrl.startsWith('about:') ||
      rawUrl.includes('script.google.com') ||
      rawUrl.includes('accounts.google.com')) {
    return false;
  }

  let hostname = '';
  try {
    hostname = new URL(rawUrl).hostname.toLowerCase();
  } catch (e) {
    return false;
  }

  // 1. ホワイトリストモード（リストに含まれるもの以外すべてブロック）
  if (mode === 'WHITELIST') {
    if (!whitelist || whitelist.length === 0) return true;

    const isAllowed = whitelist.some(item => {
      const target = item.trim().toLowerCase();
      if (!target) return false;
      return hostname === target || hostname.endsWith('.' + target) || rawUrl.toLowerCase().includes(target);
    });

    return !isAllowed;
  }

  // 2. ブラックリストモード（リストに含まれるものをブロック）
  if (mode === 'BLACKLIST') {
    if (!blacklist || blacklist.length === 0) return false;

    const isDenied = blacklist.some(item => {
      const target = item.trim().toLowerCase();
      if (!target) return false;
      return hostname === target || hostname.endsWith('.' + target) || rawUrl.toLowerCase().includes(target);
    });

    return isDenied;
  }

  return false;
}

/**
 * ブロック画面へリダイレクト
 */
function redirectToBlockedPage(tabId, originalUrl, mode) {
  const blockUrl = chrome.runtime.getURL('blocked.html') + 
    `?url=${encodeURIComponent(originalUrl)}&mode=${encodeURIComponent(mode)}`;
  chrome.tabs.update(tabId, { url: blockUrl });
}

/**
 * 外部・Content Script からの問い合わせ受信
 */
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // 教員コンソールの稼働通知（content script 経由）。GAS に console_touch を送り、
  // 児童端末がハートビート応答で ka_active=true を受け取れるようにする。
  if (message.type === 'CONSOLE_TOUCH' || message.type === 'KEEPALIVE_START') {
    consoleTouch().then(ok => sendResponse({ success: ok })).catch(() => sendResponse({ success: false }));
    return true;
  }
  // 教員コンソールのログアウト通知。GAS に console_release を送る。
  // （全アカウントがログアウトしたら GAS 側の稼働記録も消え、児童端末は省電力へ戻る）
  if (message.type === 'CONSOLE_RELEASE' || message.type === 'KEEPALIVE_STOP') {
    consoleRelease().then(ok => sendResponse({ success: ok })).catch(() => sendResponse({ success: false }));
    return true;
  }
  // 各タブからのハートビート（ローカル IPC・ネットワーク通信ではない）。
  // 稼働中（ka_active=true）は 1.5 秒レートで即時同期する。非稼働時は同期しない
  // （＝doPost を出さない）。猶予期間内のみ maybeSync が低頻度で再確認する。
  if (message.type === 'KEEPALIVE_PING') {
    maybeSync();
    sendResponse({ success: true, active: keepaliveActive });
    return true;
  }
  if (message.type === 'GET_CURRENT_STATE') {
    chrome.storage.local.get(null).then(data => {
      sendResponse(data);
    });
    return true;
  }
  if (message.type === 'TRIGGER_SYNC') {
    // 診断（直接読み込み版のポップアップ表示用）。
    // 同期の多重実行中は syncWithGas が即 return するため、その場合も直前の結果を返す。
    syncWithGas().then(() => {
      chrome.storage.local.get(null).then(data => {
        sendResponse({ success: true, data, diag: lastSyncDiag });
      });
    }).catch(err => {
      sendResponse({ success: false, error: err.toString(), diag: lastSyncDiag });
    });
    return true;
  }
  if (message.type === 'GET_SYNC_DIAG') {
    sendResponse({ success: true, diag: lastSyncDiag });
    return true;
  }
  // 疎通確認（直接読み込み版の設定画面から手動で実行される）。
  if (message.type === 'TEST_CONNECTION') {
    testGasConnection(message.url).then(function (r) { sendResponse(r); })
      .catch(function (e) { sendResponse({ ok: false, error: String(e) }); });
    return true;
  }
  // 通信状態の取得（直接読み込み版のポップアップ表示用・通信は発生しない）。
  if (message.type === 'GET_STATUS_FULL') {
    let probe = null;
    try { probe = getProbeBand(Date.now()); } catch (e) { probe = null; }
    sendResponse({
      ok: true,
      status: {
        ka_active: !!keepaliveActive,
        sync_interval_sec: keepaliveActive ? (activeIntervalMs / 1000) : 0,
        idle_drift_until: idleDriftUntil || 0,
        probe: probe
      }
    });
    return true;
  }
});
